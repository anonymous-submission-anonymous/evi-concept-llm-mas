# Bottleneck multimodal fusion

Variant: `bottleneck_fusion`

Run:

```bash
conda activate adodas
pip install -r ../requirements.txt
bash run.sh
```

Outputs are saved to:

```text
outputs/<timestamp>__bottleneck_fusion/
```

This folder is independent.
