#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, hashlib, json, os, random, re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, List
import numpy as np
import pandas as pd
from tqdm import tqdm
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score, average_precision_score, confusion_matrix
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

SESSIONS = ["A01", "B01", "B02", "B03"]
LABELS = ["D", "A", "S"]

DEFAULTS = {
    "variant": "label_session_attention",
    "train_root": "/mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip",
    "val_root": "/mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip",
    "train_labels": "",
    "val_labels": "",
    "audio_ssl_tag": "wav2vec2-chinese-xlsr",
    "vision_ssl_tag": "dinov2-large",
    "text_dim": 2048,
    "d_model": 256,
    "dropout": 0.2,
    "batch_size": 64,
    "epochs": 30,
    "lr": 1e-3,
    "weight_decay": 1e-2,
    "grad_clip": 1.0,
    "num_workers": 4,
    "seed": 42,
    "cache_dir": "cache",
    "output_root": "outputs",
    "max_participants": 0,
    "pos_weight_cap": 10.0,
    "class_balanced_weight": [3.64, 2.54, 6.78],
    "use_focal": True,
    "focal_gamma": 1.5,
    "bottleneck_tokens": 4,
    "n_heads": 4,
    "n_layers": 2,
    "lambda_align": 0.05,
    "lambda_diff": 0.01
}

def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

def parse_key(path: Path):
    school = cls = pid = None
    for p in path.parts:
        if re.fullmatch(r"SCH[_-]?\d+", p, flags=re.I): school = p
        elif re.fullmatch(r"CLS[_-]?\d+", p, flags=re.I): cls = p
        elif re.fullmatch(r"P\d+", p, flags=re.I): pid = p
    return (str(school), str(cls), str(pid)) if school and cls and pid else None

def find_feature_participants(root: Path):
    out = {}
    for p in root.rglob("*"):
        if p.is_dir() and ((p / "audio").is_dir() or (p / "video").is_dir()):
            k = parse_key(p)
            if k: out[k] = p
    return out

def find_transcript_participants(root: Path):
    out = {}
    for p in root.rglob("*"):
        if p.is_dir() and any((p / s).is_dir() for s in SESSIONS):
            k = parse_key(p)
            if k: out[k] = p
    return out

def read_text(path: Path):
    if not path.exists(): return ""
    for enc in ["utf-8", "utf-8-sig", "gb18030", "latin1"]:
        try: return path.read_text(encoding=enc)
        except Exception: pass
    return ""

def read_json(path: Path):
    if not path.exists(): return None
    for enc in ["utf-8", "utf-8-sig", "gb18030"]:
        try:
            with path.open("r", encoding=enc) as f: return json.load(f)
        except Exception: pass
    return None

def collect_nums(x, vals):
    if isinstance(x, (int, float)) and np.isfinite(x): vals.append(float(x))
    elif isinstance(x, dict):
        for v in x.values(): collect_nums(v, vals)
    elif isinstance(x, list):
        for v in x: collect_nums(v, vals)

def pad1(x, dim):
    x = np.asarray(x, dtype=np.float32).reshape(-1)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    if x.size >= dim: return x[:dim].astype(np.float32)
    y = np.zeros(dim, dtype=np.float32); y[:x.size] = x; return y

def pad2(x, dim):
    x = np.asarray(x, dtype=np.float32)
    if x.ndim == 1: x = x.reshape(-1, 1)
    else: x = x.reshape(x.shape[0], -1)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    if x.shape[1] >= dim: return x[:, :dim]
    y = np.zeros((x.shape[0], dim), dtype=np.float32); y[:, :x.shape[1]] = x; return y

def choose_npz(npz, group):
    keys = list(npz.keys())
    if group == "mel_mfcc" and "mel_features" in keys and "mfcc_features" in keys:
        mel, mfcc = npz["mel_features"], npz["mfcc_features"]
        if mel.ndim == 2 and mfcc.ndim == 2 and mel.shape[0] == mfcc.shape[0]:
            return np.concatenate([mel, mfcc], axis=1)
    for k in ["features", "feature", "embeddings", "embedding", "values", "data", "x"]:
        if k in keys and isinstance(npz[k], np.ndarray):
            return npz[k]
    for k in keys:
        if "time" in k.lower(): continue
        if isinstance(npz[k], np.ndarray) and np.issubdtype(npz[k].dtype, np.number):
            return npz[k]
    return None

def seq_summary(folder: Path, group: str, raw_dim: int, minmax=False):
    path = folder / "sequence.npz"; mult = 4 if minmax else 2
    if not path.exists(): return np.zeros(raw_dim * mult, dtype=np.float32)
    try:
        with np.load(path, allow_pickle=False) as npz:
            arr = choose_npz(npz, group)
            if arr is None: return np.zeros(raw_dim * mult, dtype=np.float32)
            arr = pad2(arr, raw_dim)
            mean, std = arr.mean(0), arr.std(0)
            if not minmax: return np.concatenate([mean, std]).astype(np.float32)
            return np.concatenate([mean, std, arr.min(0), arr.max(0)]).astype(np.float32)
    except Exception:
        return np.zeros(raw_dim * mult, dtype=np.float32)

def pooled(folder: Path, dim: int):
    pq, js = folder / "pooled.parquet", folder / "pooled.json"
    if pq.exists():
        try:
            df = pd.read_parquet(pq)
            a = df.select_dtypes(include=[np.number]).to_numpy(np.float32)
            if a.size: return pad1(np.nanmean(a, axis=0), dim)
        except Exception: pass
    vals = []
    if js.exists(): collect_nums(read_json(js), vals)
    return pad1(np.asarray(vals, dtype=np.float32), dim)

def transcript_text(troot: Optional[Path], sess):
    if troot is None: return ""
    d = troot / sess
    for name in ["clean_transcript.txt", "normalized_transcript.txt", "raw_transcript.txt"]:
        txt = read_text(d / name).strip()
        if txt: return txt
    return ""

def hash_text(text, dim):
    v = np.zeros(dim, dtype=np.float32)
    text = re.sub(r"\s+", " ", text.strip().lower())
    if not text: return v
    chars = list(text)
    for n in [1, 2, 3]:
        if len(chars) < n: continue
        for i in range(len(chars) - n + 1):
            gram = "".join(chars[i:i+n])
            h = int(hashlib.md5(gram.encode("utf-8")).hexdigest(), 16)
            v[h % dim] += 1.0 if ((h >> 7) & 1) == 0 else -1.0
    norm = np.linalg.norm(v)
    return (v / norm).astype(np.float32) if norm > 0 else v

def text_stats(text):
    return np.asarray([
        len(text),
        len([x for x in re.split(r"\s+", text.strip()) if x]) if text.strip() else 0,
        len(re.findall(r"[\u4e00-\u9fff]", text)),
        len(re.findall(r"\d", text)),
        len(re.findall(r"[^\w\s\u4e00-\u9fff]", text)),
    ], dtype=np.float32)

def load_session(froot, troot, sess, audio_tag, vision_tag, text_dim):
    if froot is None:
        audio = np.zeros(2238, np.float32); video = np.zeros(2084, np.float32); ege = np.zeros(88, np.float32); qbase = np.zeros(16, np.float32)
    else:
        ad, vd = froot / "audio", froot / "video"
        mel = seq_summary(ad / "mel_mfcc" / sess, "mel_mfcc", 93)
        vad = seq_summary(ad / "vad" / sess, "vad", 1, minmax=True)
        assl = seq_summary(ad / "ssl_embed" / audio_tag / sess, "ssl_embed", 1024)
        audio = np.concatenate([mel, vad, assl]).astype(np.float32)
        head = seq_summary(vd / "headpose_geom" / sess, "headpose_geom", 5)
        face = seq_summary(vd / "face_behavior" / sess, "face_behavior", 5)
        qc = seq_summary(vd / "qc_stats" / sess, "qc_stats", 4)
        vadagg = seq_summary(vd / "vad_agg" / sess, "vad_agg", 4)
        vssl = seq_summary(vd / "vision_ssl_embed" / vision_tag / sess, "vision_ssl_embed", 1024)
        video = np.concatenate([head, face, qc, vadagg, vssl]).astype(np.float32)
        ege = pooled(ad / "egemaps" / sess, 88)
        qbase = np.concatenate([vad, qc[:8], vadagg[:4]]).astype(np.float32)
    txt = transcript_text(troot, sess)
    tvec = hash_text(txt, text_dim)
    q = np.concatenate([pad1(qbase, 16), text_stats(txt), np.asarray([1.0 if txt else 0.0], np.float32)])
    return audio, video, ege, tvec, q.astype(np.float32), float(bool(txt))

def guess_cols(df):
    cols = {c.lower(): c for c in df.columns}
    def f(xs):
        for x in xs:
            if x in cols: return cols[x]
        return None
    return f(["anon_school","school","school_id"]), f(["anon_class","class","class_id","cls"]), f(["anon_pid","participant_id","pid","person_id","subject_id"]), f(["label_d","d","depression","dep","y_d"]), f(["label_a","a","anxiety","anx","y_a"]), f(["label_s","s","stress","str","y_s"])

def read_labels(path):
    df = pd.read_csv(path)
    sc, cl, pid, d, a, s = guess_cols(df)
    if not all([sc, cl, pid, d, a, s]):
        raise ValueError(f"Cannot detect label columns in {path}. Columns={list(df.columns)}")
    out = df[[sc, cl, pid, d, a, s]].copy()
    out.columns = ["school","class_id","participant_id","label_D","label_A","label_S"]
    for c in ["school","class_id","participant_id"]: out[c] = out[c].astype(str)
    for c in ["label_D","label_A","label_S"]: out[c] = pd.to_numeric(out[c], errors="coerce").fillna(0).astype(int)
    return out

def autodiscover_labels(root):
    for p in root.rglob("*.csv"):
        if not any(x in p.name.lower() for x in ["label","manifest","a1","train","val"]): continue
        try:
            if all(guess_cols(pd.read_csv(p, nrows=5))): return p
        except Exception: pass
    return None

def build_cache(root, cache_dir, split, labels_csv, audio_tag, vision_tag, text_dim, maxp):
    cache_dir.mkdir(parents=True, exist_ok=True)
    cfile = cache_dir / f"{split}_{audio_tag}_{vision_tag}_text{text_dim}.npz"
    if cfile.exists(): return dict(np.load(cfile, allow_pickle=True))
    labels_csv = labels_csv or autodiscover_labels(root)
    if labels_csv is None: raise FileNotFoundError(f"No labels CSV discovered under {root}; pass TRAIN_LABELS/VAL_LABELS.")
    labels = read_labels(labels_csv)
    if maxp: labels = labels.iloc[:maxp]
    fmap, tmap = find_feature_participants(root), find_transcript_participants(root)
    A,V,E,T,Q,M,Y,IDS = [],[],[],[],[],[],[],[]
    for _, row in tqdm(labels.iterrows(), total=len(labels), desc=f"building {split} cache"):
        key = (str(row.school), str(row.class_id), str(row.participant_id))
        froot, troot = fmap.get(key), tmap.get(key)
        aa,vv,ee,tt,qq,mm = [],[],[],[],[],[]
        for sess in SESSIONS:
            a,v,e,t,q,tp = load_session(froot, troot, sess, audio_tag, vision_tag, text_dim)
            aa.append(a); vv.append(v); ee.append(e); tt.append(t); qq.append(q); mm.append(1.0 if (froot is not None or tp) else 0.0)
        A.append(np.stack(aa)); V.append(np.stack(vv)); E.append(np.stack(ee)); T.append(np.stack(tt)); Q.append(np.stack(qq)); M.append(np.asarray(mm, np.float32))
        Y.append(row[["label_D","label_A","label_S"]].to_numpy(np.float32)); IDS.append("|".join(key))
    data = {"audio":np.stack(A), "video":np.stack(V), "ege":np.stack(E), "text":np.stack(T), "quality":np.stack(Q), "session_mask":np.stack(M), "y":np.stack(Y), "ids":np.asarray(IDS, dtype=object)}
    np.savez_compressed(cfile, **data)
    (cache_dir / f"{split}_cache_meta.json").write_text(json.dumps({"root":str(root), "labels":str(labels_csv), "n":len(IDS)}, indent=2), encoding="utf-8")
    return data

def fit_scaler(data):
    sc = {}
    for k in ["audio","video","ege","quality"]:
        flat = data[k].reshape(-1, data[k].shape[-1])
        m, s = flat.mean(0), flat.std(0); s[s < 1e-6] = 1.0
        sc[k] = (m.astype(np.float32), s.astype(np.float32))
    return sc

def apply_scaler(data, sc):
    out = dict(data)
    for k,(m,s) in sc.items(): out[k] = ((out[k] - m) / s).astype(np.float32)
    return out

class ADODASDataset(Dataset):
    def __init__(self, data): self.data = data
    def __len__(self): return self.data["y"].shape[0]
    def __getitem__(self, i):
        d = {k: torch.tensor(self.data[k][i], dtype=torch.float32) for k in ["audio","video","ege","text","quality","session_mask","y"]}
        d["id"] = str(self.data["ids"][i])
        return d

def mlp(in_dim, out_dim, hidden, dropout):
    return nn.Sequential(nn.LayerNorm(in_dim), nn.Linear(in_dim, hidden), nn.GELU(), nn.Dropout(dropout), nn.Linear(hidden, out_dim))

class Enc(nn.Module):
    def __init__(self, dims, d, dropout):
        super().__init__()
        self.audio = mlp(dims["audio"], d, d, dropout)
        self.video = mlp(dims["video"], d, d, dropout)
        self.ege = mlp(dims["ege"], d//2, d, dropout)
        self.text = mlp(dims["text"], d, d, dropout)
        self.quality = mlp(dims["quality"], d//2, d, dropout)
        self.sid = nn.Embedding(4, d//4)
    def forward(self, b):
        B,S = b["audio"].shape[:2]
        sid = torch.arange(S, device=b["audio"].device).unsqueeze(0).expand(B,S)
        return dict(audio=self.audio(b["audio"]), video=self.video(b["video"]), ege=self.ege(b["ege"]), text=self.text(b["text"]), quality=self.quality(b["quality"]), sid=self.sid(sid))

class Model1(nn.Module):
    def __init__(self, dims, cfg):
        super().__init__(); d=cfg["d_model"]; dr=cfg["dropout"]; self.enc=Enc(dims,d,dr); self.fuse=mlp(d+d+d//2+d+d//2+d//4,d,d,dr); self.att=nn.ModuleList([nn.Linear(d,1) for _ in range(3)]); self.head=nn.ModuleList([nn.Linear(d,1) for _ in range(3)])
    def forward(self,b,return_diag=False):
        z=self.enc(b); h=self.fuse(torch.cat([z["audio"],z["video"],z["ege"],z["text"],z["quality"],z["sid"]],-1)); mask=b["session_mask"].bool(); outs=[]; att=[]
        for c in range(3):
            a=torch.softmax(self.att[c](h).squeeze(-1).masked_fill(~mask,-1e4),1); outs.append(self.head[c]((a.unsqueeze(-1)*h).sum(1))); att.append(a)
        diag={"session_attention":torch.stack(att,-1)}
        return (torch.cat(outs,-1),diag) if return_diag else torch.cat(outs,-1)

class Model2(nn.Module):
    def __init__(self, dims, cfg):
        super().__init__(); d=cfg["d_model"]; dr=cfg["dropout"]; self.enc=Enc(dims,d,dr); self.fuse=mlp(d+d+d//2+d+d//2+d//4,d,d,dr); self.att=nn.Linear(d,1); self.base=nn.Linear(d,3); self.corr=mlp(d+3,3,d,dr); self.scale=nn.Parameter(torch.tensor(0.2))
    def forward(self,b,return_diag=False):
        z=self.enc(b); h=self.fuse(torch.cat([z["audio"],z["video"],z["ege"],z["text"],z["quality"],z["sid"]],-1)); a=torch.softmax(self.att(h).squeeze(-1).masked_fill(~b["session_mask"].bool(),-1e4),1); hp=(a.unsqueeze(-1)*h).sum(1)
        base=self.base(hp); delta=self.corr(torch.cat([hp, torch.sigmoid(base.detach())], -1)); logits=base+torch.tanh(self.scale)*delta
        return (logits, {"session_attention":a,"base_logits":base,"corr_delta":delta}) if return_diag else logits

class Model3(nn.Module):
    def __init__(self, dims, cfg):
        super().__init__(); d=cfg["d_model"]; dr=cfg["dropout"]; K=cfg["bottleneck_tokens"]; self.K=K; self.enc=Enc(dims,d,dr); self.pe=nn.Linear(d//2,d); self.pq=nn.Linear(d//2,d); self.ps=nn.Linear(d//4,d); self.bn=nn.Parameter(torch.randn(K,d)*0.02)
        layer=nn.TransformerEncoderLayer(d_model=d,nhead=cfg["n_heads"],dim_feedforward=4*d,dropout=dr,activation="gelu",batch_first=True,norm_first=True)
        self.tr=nn.TransformerEncoder(layer,cfg["n_layers"]); self.out=mlp(d,d,d,dr); self.att=nn.Linear(d,1); self.head=nn.Linear(d,3)
    def forward(self,b,return_diag=False):
        z=self.enc(b); B,S=z["audio"].shape[:2]; toks=torch.stack([z["audio"],z["video"],z["text"],self.pe(z["ege"]),self.pq(z["quality"]),self.ps(z["sid"])],2); bn=self.bn.view(1,1,self.K,-1).expand(B,S,self.K,-1)
        o=self.tr(torch.cat([toks,bn],2).reshape(B*S,6+self.K,-1)).reshape(B,S,6+self.K,-1); bout=o[:,:,-self.K:,:]; h=self.out(bout.mean(2)); a=torch.softmax(self.att(h).squeeze(-1).masked_fill(~b["session_mask"].bool(),-1e4),1); logits=self.head((a.unsqueeze(-1)*h).sum(1))
        return (logits, {"session_attention":a,"bottleneck_norm":bout.norm(dim=-1).mean(2)}) if return_diag else logits

def orth(c,p):
    B,S,D=c.shape; c=c.reshape(B*S,D); p=p.reshape(B*S,D); c=F.normalize(c-c.mean(0,keepdim=True),dim=0); p=F.normalize(p-p.mean(0,keepdim=True),dim=0); return ((c.T@p/max(c.shape[0],1))**2).mean()

class Model4(nn.Module):
    def __init__(self, dims, cfg):
        super().__init__(); d=cfg["d_model"]; dr=cfg["dropout"]; self.enc=Enc(dims,d,dr); cd=d//2
        self.ca=mlp(d,cd,d,dr); self.cv=mlp(d,cd,d,dr); self.ct=mlp(d,cd,d,dr); self.pa=mlp(d,cd,d,dr); self.pv=mlp(d,cd,d,dr); self.pt=mlp(d,cd,d,dr)
        self.g=nn.Sequential(nn.LayerNorm(d//2),nn.Linear(d//2,3),nn.Sigmoid()); self.fuse=mlp(cd*6+d//2+d//4,d,d,dr); self.att=nn.Linear(d,1); self.head=nn.Linear(d,3)
    def forward(self,b,return_diag=False):
        z=self.enc(b); ca,cv,ct=self.ca(z["audio"]),self.cv(z["video"]),self.ct(z["text"]); pa,pv,pt=self.pa(z["audio"]),self.pv(z["video"]),self.pt(z["text"]); g=self.g(z["quality"])
        h=self.fuse(torch.cat([ca,cv,ct,pa*g[...,0:1],pv*g[...,1:2],pt*g[...,2:3],z["ege"],z["sid"]],-1)); a=torch.softmax(self.att(h).squeeze(-1).masked_fill(~b["session_mask"].bool(),-1e4),1); logits=self.head((a.unsqueeze(-1)*h).sum(1))
        return (logits, {"session_attention":a,"modality_gates":g,"aux_align":F.mse_loss(ca,cv)+F.mse_loss(ca,ct)+F.mse_loss(cv,ct),"aux_diff":orth(ca,pa)+orth(cv,pv)+orth(ct,pt)}) if return_diag else logits

def build_model(variant, dims, cfg):
    if variant == "label_session_attention": return Model1(dims, cfg)
    if variant == "ds_loss_corr_head": return Model2(dims, cfg)
    if variant == "bottleneck_fusion": return Model3(dims, cfg)
    if variant == "misa_quality_gates": return Model4(dims, cfg)
    raise ValueError(variant)

def move(b,dev): return {k:(v.to(dev) if torch.is_tensor(v) else v) for k,v in b.items()}
def sigmoid(x): return 1/(1+np.exp(-x))
def pos_weight(y, cap):
    pos=y.sum(0); neg=y.shape[0]-pos; return torch.tensor(np.clip(neg/np.clip(pos,1,None),1,cap),dtype=torch.float32)

def compute_metrics(y, prob, th=0.5):
    pred=(prob>=th).astype(int); rows=[]; f1s=[]
    for j,lab in enumerate(LABELS):
        p,r,f1,_=precision_recall_fscore_support(y[:,j],pred[:,j],average="binary",zero_division=0)
        try: auc=roc_auc_score(y[:,j],prob[:,j])
        except Exception: auc=np.nan
        try: ap=average_precision_score(y[:,j],prob[:,j])
        except Exception: ap=np.nan
        tn,fp,fn,tp=confusion_matrix(y[:,j],pred[:,j],labels=[0,1]).ravel()
        rows.append(dict(label=lab,precision=p,recall=r,f1=f1,auroc=auc,average_precision=ap,tn=tn,fp=fp,fn=fn,tp=tp,threshold=th)); f1s.append(f1)
    m={f"f1_{lab}":rows[i]["f1"] for i,lab in enumerate(LABELS)}
    m.update({f"precision_{lab}":rows[i]["precision"] for i,lab in enumerate(LABELS)})
    m.update({f"recall_{lab}":rows[i]["recall"] for i,lab in enumerate(LABELS)})
    m["mean_f1"]=float(np.mean(f1s))
    return m,pd.DataFrame(rows)

def threshold_sweep(y, prob):
    rows=[]
    for j,lab in enumerate(LABELS):
        for th in np.round(np.arange(0.05,0.96,0.01),2):
            p,r,f1,_=precision_recall_fscore_support(y[:,j],(prob[:,j]>=th).astype(int),average="binary",zero_division=0)
            rows.append(dict(label=lab,threshold=float(th),precision=p,recall=r,f1=f1))
    return pd.DataFrame(rows)

@torch.no_grad()
def evaluate(model, loader, dev, variant, out=None):
    model.eval(); ids=[]; ys=[]; logits=[]; ds={}
    for b in loader:
        b=move(b,dev); logit,diag=model(b,return_diag=True); ids.extend(b["id"]); ys.append(b["y"].cpu().numpy()); logits.append(logit.cpu().numpy())
        for k,v in diag.items():
            if torch.is_tensor(v): ds.setdefault(k,[]).append(v.detach().cpu().numpy())
    y=np.concatenate(ys); logit=np.concatenate(logits); prob=sigmoid(logit); m,conf=compute_metrics(y,prob); sw=threshold_sweep(y,prob); best=sw.sort_values(["label","f1"],ascending=[True,False]).groupby("label").head(1)
    if out:
        pred=pd.DataFrame({"id":ids,"y_D":y[:,0],"y_A":y[:,1],"y_S":y[:,2],"logit_D":logit[:,0],"logit_A":logit[:,1],"logit_S":logit[:,2],"p_D":prob[:,0],"p_A":prob[:,1],"p_S":prob[:,2],"pred_D_0.5":(prob[:,0]>=0.5).astype(int),"pred_A_0.5":(prob[:,1]>=0.5).astype(int),"pred_S_0.5":(prob[:,2]>=0.5).astype(int)})
        pred.to_csv(out/"val_predictions.csv",index=False); sw.to_csv(out/"val_threshold_sweep.csv",index=False); best.to_csv(out/"val_best_thresholds.csv",index=False); conf.to_csv(out/"val_confusion_by_label.csv",index=False); save_errors(pred,out/"val_error_cases.csv"); save_diag(ds,ids,variant,out)
    for _,r in best.iterrows(): m[f"best_threshold_{r.label}"]=float(r.threshold); m[f"best_f1_{r.label}"]=float(r.f1)
    return m

def save_errors(pred,path):
    allrows=[]
    for lab in LABELS:
        sub=pred[pred[f"y_{lab}"]!=pred[f"pred_{lab}_0.5"]][["id",f"y_{lab}",f"p_{lab}",f"pred_{lab}_0.5"]].copy()
        sub["label"]=lab; sub["abs_margin_from_0.5"]=np.abs(sub[f"p_{lab}"]-0.5); allrows.append(sub)
    pd.concat(allrows,ignore_index=True).sort_values("abs_margin_from_0.5").to_csv(path,index=False)

def save_diag(ds,ids,variant,out):
    def cat(k): return np.concatenate(ds[k],0) if k in ds else None
    if variant=="label_session_attention":
        a=cat("session_attention")
        if a is not None:
            rows=[dict(id=pid,session=s,label=lab,attention=a[i,si,li]) for i,pid in enumerate(ids) for si,s in enumerate(SESSIONS) for li,lab in enumerate(LABELS)]
            pd.DataFrame(rows).to_csv(out/"val_session_attention.csv",index=False)
    elif variant=="ds_loss_corr_head":
        b,d=cat("base_logits"),cat("corr_delta")
        if b is not None:
            df=pd.DataFrame({"id":ids})
            for j,lab in enumerate(LABELS): df[f"base_logit_{lab}"]=b[:,j]; df[f"corr_delta_{lab}"]=d[:,j]
            df.to_csv(out/"val_label_correlation_residuals.csv",index=False)
    elif variant=="bottleneck_fusion":
        bn=cat("bottleneck_norm")
        if bn is not None:
            rows=[dict(id=pid,session=s,bottleneck_norm=bn[i,si]) for i,pid in enumerate(ids) for si,s in enumerate(SESSIONS)]
            pd.DataFrame(rows).to_csv(out/"val_bottleneck_diagnostics.csv",index=False)
    elif variant=="misa_quality_gates":
        g=cat("modality_gates")
        if g is not None:
            rows=[dict(id=pid,session=s,modality=m,gate=g[i,si,mi]) for i,pid in enumerate(ids) for si,s in enumerate(SESSIONS) for mi,m in enumerate(["audio","video","text"])]
            pd.DataFrame(rows).to_csv(out/"val_modality_gates.csv",index=False)

def loss_fn(logit,y,diag,variant,pw,cfg):
    if variant=="ds_loss_corr_head":
        w=torch.tensor(cfg["class_balanced_weight"],dtype=torch.float32,device=logit.device)
        loss=F.binary_cross_entropy_with_logits(logit,y,pos_weight=w,reduction="none")
        if cfg.get("use_focal",True):
            p=torch.sigmoid(logit); pt=p*y+(1-p)*(1-y); loss=loss*((1-pt)**cfg["focal_gamma"])
        return loss.mean()
    loss=F.binary_cross_entropy_with_logits(logit,y,pos_weight=pw.to(logit.device))
    if variant=="misa_quality_gates":
        loss=loss+cfg["lambda_align"]*diag["aux_align"]+cfg["lambda_diff"]*diag["aux_diff"]
    return loss

def train(model,tr,va,dev,cfg,out,train_y):
    opt=torch.optim.AdamW(model.parameters(),lr=cfg["lr"],weight_decay=cfg["weight_decay"]); pw=pos_weight(train_y,cfg["pos_weight_cap"]); best=-1; log=[]; aux=[]
    for ep in range(1,cfg["epochs"]+1):
        model.train(); losses=[]; al=[]; dl=[]
        for b in tr:
            b=move(b,dev); opt.zero_grad(set_to_none=True); logit,diag=model(b,return_diag=True); loss=loss_fn(logit,b["y"],diag,cfg["variant"],pw,cfg); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),cfg["grad_clip"]); opt.step(); losses.append(float(loss.detach().cpu()))
            if cfg["variant"]=="misa_quality_gates": al.append(float(diag["aux_align"].detach().cpu())); dl.append(float(diag["aux_diff"].detach().cpu()))
        m=evaluate(model,va,dev,cfg["variant"]); row={"epoch":ep,"train_loss":float(np.mean(losses)),**m}; print(json.dumps(row),flush=True); log.append(row); pd.DataFrame(log).to_csv(out/"train_log.csv",index=False)
        if cfg["variant"]=="misa_quality_gates": aux.append({"epoch":ep,"align_loss":float(np.mean(al)),"diff_loss":float(np.mean(dl))}); pd.DataFrame(aux).to_csv(out/"train_aux_losses.csv",index=False)
        if m["mean_f1"]>best: best=m["mean_f1"]; torch.save({"model":model.state_dict(),"cfg":cfg,"metrics":m},out/"checkpoint_best.pt")
    ck=torch.load(out/"checkpoint_best.pt",map_location=dev); model.load_state_dict(ck["model"]); final=evaluate(model,va,dev,cfg["variant"],out); (out/"best_metrics.json").write_text(json.dumps(final,indent=2),encoding="utf-8"); return final

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",type=Path,default=Path("config.json")); ap.add_argument("--train-root",type=Path); ap.add_argument("--val-root",type=Path); ap.add_argument("--train-labels",type=Path); ap.add_argument("--val-labels",type=Path); ap.add_argument("--epochs",type=int); ap.add_argument("--max-participants",type=int)
    args=ap.parse_args(); cfg=dict(DEFAULTS)
    if args.config.exists(): cfg.update(json.loads(args.config.read_text()))
    if os.environ.get("TRAIN_ROOT"): cfg["train_root"]=os.environ["TRAIN_ROOT"]
    if os.environ.get("VAL_ROOT"): cfg["val_root"]=os.environ["VAL_ROOT"]
    if os.environ.get("TRAIN_LABELS"): cfg["train_labels"]=os.environ["TRAIN_LABELS"]
    if os.environ.get("VAL_LABELS"): cfg["val_labels"]=os.environ["VAL_LABELS"]
    if args.train_root: cfg["train_root"]=str(args.train_root)
    if args.val_root: cfg["val_root"]=str(args.val_root)
    if args.train_labels: cfg["train_labels"]=str(args.train_labels)
    if args.val_labels: cfg["val_labels"]=str(args.val_labels)
    if args.epochs: cfg["epochs"]=args.epochs
    if args.max_participants: cfg["max_participants"]=args.max_participants
    set_seed(cfg["seed"])
    out=Path(cfg["output_root"])/(datetime.now().strftime("%Y%m%d_%H%M%S")+"__"+cfg["variant"]); out.mkdir(parents=True,exist_ok=True); (out/"config_used.json").write_text(json.dumps(cfg,indent=2),encoding="utf-8")
    maxp=cfg["max_participants"] or None
    train_raw=build_cache(Path(cfg["train_root"]),Path(cfg["cache_dir"]),"train",Path(cfg["train_labels"]) if cfg["train_labels"] else None,cfg["audio_ssl_tag"],cfg["vision_ssl_tag"],cfg["text_dim"],maxp)
    val_raw=build_cache(Path(cfg["val_root"]),Path(cfg["cache_dir"]),"val",Path(cfg["val_labels"]) if cfg["val_labels"] else None,cfg["audio_ssl_tag"],cfg["vision_ssl_tag"],cfg["text_dim"],maxp)
    sc=fit_scaler(train_raw); train_data=apply_scaler(train_raw,sc); val_data=apply_scaler(val_raw,sc)
    dims={k:train_data[k].shape[-1] for k in ["audio","video","ege","text","quality"]}; (out/"input_dims.json").write_text(json.dumps(dims,indent=2),encoding="utf-8")
    print("[INFO] output",out); print("[INFO] dims",dims); print("[INFO] train/val",train_data["y"].shape,val_data["y"].shape); print("[INFO] train positive rates",train_data["y"].mean(0).tolist())
    tr=DataLoader(ADODASDataset(train_data),batch_size=cfg["batch_size"],shuffle=True,num_workers=cfg["num_workers"],pin_memory=True)
    va=DataLoader(ADODASDataset(val_data),batch_size=cfg["batch_size"],shuffle=False,num_workers=cfg["num_workers"],pin_memory=True)
    dev=torch.device("cuda" if torch.cuda.is_available() else "cpu"); model=build_model(cfg["variant"],dims,cfg).to(dev); print("[INFO] device",dev,"params",sum(p.numel() for p in model.parameters()))
    final=train(model,tr,va,dev,cfg,out,train_data["y"]); print(json.dumps(final,indent=2))
if __name__ == "__main__": main()
