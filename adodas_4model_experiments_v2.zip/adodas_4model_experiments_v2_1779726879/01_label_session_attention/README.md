# Label-specific session attention

Variant: `label_session_attention`

Run:

```bash
conda activate adodas
pip install -r ../requirements.txt
bash run.sh
```

Outputs are saved to:

```text
outputs/<timestamp>__label_session_attention/
```

This folder is independent.
