# MISA-style common/private + quality gates

Variant: `misa_quality_gates`

Run:

```bash
conda activate adodas
pip install -r ../requirements.txt
bash run.sh
```

Outputs are saved to:

```text
outputs/<timestamp>__misa_quality_gates/
```

This folder is independent.
