#!/usr/bin/env bash
set -euo pipefail
TRAIN_ROOT="${TRAIN_ROOT:-/mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip}"
VAL_ROOT="${VAL_ROOT:-/mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip}"
CMD=(python train.py --config config.json --train-root "$TRAIN_ROOT" --val-root "$VAL_ROOT")
if [[ -n "${TRAIN_LABELS:-}" ]]; then CMD+=(--train-labels "$TRAIN_LABELS"); fi
if [[ -n "${VAL_LABELS:-}" ]]; then CMD+=(--val-labels "$VAL_LABELS"); fi
echo "[INFO] running 04_misa_quality_gates: MISA-style common/private + quality gates"
printf ' %q' "${CMD[@]}"; echo
"${CMD[@]}"
