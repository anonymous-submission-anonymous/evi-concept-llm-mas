#!/usr/bin/env python
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
LABELS=["D","A","S"]
ap=argparse.ArgumentParser()
ap.add_argument("--preds",nargs="+",required=True)
ap.add_argument("--out",type=Path,required=True)
args=ap.parse_args()
args.out.mkdir(parents=True,exist_ok=True)
dfs=[pd.read_csv(p) for p in args.preds]
base=dfs[0][["id","y_D","y_A","y_S"]].copy()
for lab in LABELS:
    base[f"p_{lab}"]=np.mean([df[f"p_{lab}"].values for df in dfs],axis=0)
    base[f"pred_{lab}_0.5"]=(base[f"p_{lab}"]>=0.5).astype(int)
rows=[]
for lab in LABELS:
    y=base[f"y_{lab}"].values
    pred=base[f"pred_{lab}_0.5"].values
    p,r,f1,_=precision_recall_fscore_support(y,pred,average="binary",zero_division=0)
    try: auc=roc_auc_score(y,base[f"p_{lab}"].values)
    except Exception: auc=np.nan
    rows.append({"label":lab,"precision":p,"recall":r,"f1":f1,"auroc":auc})
m=pd.DataFrame(rows)
m.loc[len(m)]={"label":"mean","precision":np.nan,"recall":np.nan,"f1":m.f1.mean(),"auroc":m.auroc.mean()}
base.to_csv(args.out/"ensemble_val_predictions.csv",index=False)
m.to_csv(args.out/"ensemble_metrics.csv",index=False)
print(m)
