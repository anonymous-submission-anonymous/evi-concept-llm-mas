# AdoDAS A1 Four-Model Experiments

This package contains four independent runnable experiment folders.

Shared strategy for all four:

```text
multimodal-first A1 model
+ transcript branch
+ audio/video/eGeMAPS/quality features
+ participant-level Depression/Anxiety/Stress prediction
```

Each folder tests one unique strategy:

| Folder | Strategy |
|---|---|
| `01_label_session_attention` | Label-specific session attention |
| `02_ds_loss_corr_head` | D/S-aware loss + label-correlation head |
| `03_bottleneck_fusion` | Bottleneck multimodal fusion |
| `04_misa_quality_gates` | MISA-style common/private decomposition + quality gates |

Default paths:

```bash
TRAIN_ROOT=/mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip
VAL_ROOT=/mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip
```

Run all four on 4 GPUs:

```bash
conda activate adodas
pip install -r requirements.txt
bash run_all_4gpu.sh
```

Run one model:

```bash
cd 01_label_session_attention
bash run.sh
```

If labels are not discovered automatically:

```bash
TRAIN_LABELS=/path/to/train_labels.csv VAL_LABELS=/path/to/val_labels.csv bash run.sh
```

Outputs:

```text
outputs/<timestamp>__<variant>/
├── config_used.json
├── input_dims.json
├── train_log.csv
├── best_metrics.json
├── val_predictions.csv
├── val_threshold_sweep.csv
├── val_best_thresholds.csv
├── val_confusion_by_label.csv
├── val_error_cases.csv
├── checkpoint_best.pt
└── strategy-specific diagnostics
```

This is a practical scaffold. It uses pooled/session-level summaries and deterministic transcript hash features so it can run offline. Claude Code can replace the text hash branch with MacBERT/Chinese-RoBERTa or replace pooled summaries with the full MTCN sequence backbone.
