# D/S-aware loss + label-correlation head

Variant: `ds_loss_corr_head`

Run:

```bash
conda activate adodas
pip install -r ../requirements.txt
bash run.sh
```

Outputs are saved to:

```text
outputs/<timestamp>__ds_loss_corr_head/
```

This folder is independent.
