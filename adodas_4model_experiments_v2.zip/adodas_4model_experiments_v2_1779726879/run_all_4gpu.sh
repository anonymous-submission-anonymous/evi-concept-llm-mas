#!/usr/bin/env bash
set -euo pipefail
TRAIN_ROOT="${TRAIN_ROOT:-/mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip}"
VAL_ROOT="${VAL_ROOT:-/mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip}"
echo "[INFO] TRAIN_ROOT=$TRAIN_ROOT"
echo "[INFO] VAL_ROOT=$VAL_ROOT"

run_one () {
  local gpu="$1"
  local folder="$2"
  echo "[INFO] launching $folder on GPU $gpu"
  (cd "$folder" && CUDA_VISIBLE_DEVICES="$gpu" TRAIN_ROOT="$TRAIN_ROOT" VAL_ROOT="$VAL_ROOT" bash run.sh) > "${folder}/run_gpu${gpu}.log" 2>&1 &
}
run_one 0 01_label_session_attention
run_one 1 02_ds_loss_corr_head
run_one 2 03_bottleneck_fusion
run_one 3 04_misa_quality_gates
wait
echo "[INFO] all four runs finished"
