Optional notebooks for exploratory checks.

Suggested notebook cells:
- word-count distribution
- manual inspection of validated outputs
- aggregate comparison between SFT and raw Qwen runs
