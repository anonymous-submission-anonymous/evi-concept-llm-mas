#!/usr/bin/env bash
set -euo pipefail

CONFIG=${1:-configs/sft_qwen36_27b.yaml}
RUN_ID=${RUN_ID:-$(python - <<'PY'
from datetime import datetime
print(datetime.now().strftime('%Y%m%d_%H%M%S'))
PY
)}

mkdir -p logs

echo "Using config: ${CONFIG}"
echo "Run ID: ${RUN_ID}"

python scripts/01_prepare_data.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/02_build_concept_groups.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/03_run_extraction.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/04_validate_outputs.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/05_build_matrix.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/06_make_report.py --config "${CONFIG}" --run_id "${RUN_ID}"

echo "Done."
