#!/usr/bin/env bash
set -euo pipefail

# Run four independent 9B SFT LoRA extraction shards, one per GPU.
# Recommended usage inside screen:
#   conda activate concepts
#   bash run_4gpu_shards.sh

mkdir -p logs
STAMP=$(date +%Y%m%d_%H%M%S)

echo "Launching 4 shard jobs at ${STAMP}"

CUDA_VISIBLE_DEVICES=0 VLLM_USE_V1=0 bash run_extraction.sh configs/sft_qwen35_9b_shard0.yaml \
  > "logs/qwen35_9b_shard0_${STAMP}.log" 2>&1 &
PID0=$!

CUDA_VISIBLE_DEVICES=1 VLLM_USE_V1=0 bash run_extraction.sh configs/sft_qwen35_9b_shard1.yaml \
  > "logs/qwen35_9b_shard1_${STAMP}.log" 2>&1 &
PID1=$!

CUDA_VISIBLE_DEVICES=2 VLLM_USE_V1=0 bash run_extraction.sh configs/sft_qwen35_9b_shard2.yaml \
  > "logs/qwen35_9b_shard2_${STAMP}.log" 2>&1 &
PID2=$!

CUDA_VISIBLE_DEVICES=3 VLLM_USE_V1=0 bash run_extraction.sh configs/sft_qwen35_9b_shard3.yaml \
  > "logs/qwen35_9b_shard3_${STAMP}.log" 2>&1 &
PID3=$!

echo "PIDs: ${PID0} ${PID1} ${PID2} ${PID3}"
wait ${PID0} ${PID1} ${PID2} ${PID3}

echo "All 4 shard jobs finished."
