# 9B Offline Concept Extraction Project

This package runs concept extraction with an offline vLLM job. It is optimized for the LoRA SFT 9B model:

```text
/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B-concept-sft-lora-v2
```

The expected model layout is:

```text
base model:   /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B
LoRA adapter: /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B-concept-sft-lora-v2/adapter
```

The project extracts concepts from:

```text
/mnt/disk1/wbjtu/tzbjtu/somental/data/anonymizing_sentiment_cleaned.csv
```

with columns:

```text
users,text,sentiment,time
```

`text` is the post body used for concept extraction.

## Why 9B uses sharding

For 27B, one job used tensor parallelism across 4 GPUs. For 9B, the model should fit on one L20, so the recommended strategy is:

```text
4 independent jobs
1 GPU per job
tensor_parallel_size: 1
num_shards: 4
```

This avoids tensor-parallel communication overhead and gives better wall-clock throughput.

## Files

```text
configs/sft_qwen35_9b.yaml          # one-GPU 50-row pilot
configs/sft_qwen35_9b_shard0.yaml   # full shard 0 on GPU 0
configs/sft_qwen35_9b_shard1.yaml   # full shard 1 on GPU 1
configs/sft_qwen35_9b_shard2.yaml   # full shard 2 on GPU 2
configs/sft_qwen35_9b_shard3.yaml   # full shard 3 on GPU 3
configs/raw_qwen35_9b.yaml          # optional raw 9B pilot baseline
concepts/final_concepts.yaml        # canonical concept bank
prompts/extraction_prompt.yaml      # compact JSON extraction prompt
run_extraction.sh                   # single config run
run_4gpu_shards.sh                  # launch four full shard jobs
scripts/07_merge_shards.py          # merge four shard matrices
```

## Step 1: inspect model folders

```bash
SFT9=/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B-concept-sft-lora-v2
BASE9=/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B

ls -lh "$SFT9" | head -50
ls -lh "$BASE9" | head -50
find "$SFT9" -maxdepth 2 -type f \( -name "adapter_config.json" -o -name "adapter_model.safetensors" -o -name "*.safetensors" \) -print
```

If the adapter is not under `adapter/`, edit `configs/sft_qwen35_9b*.yaml` and change `model.lora_adapter_path`.

## Step 2: run one-GPU pilot

```bash
cd /mnt/disk1/wbjtu/tzbjtu/somental/psycbm
conda activate concepts

CUDA_VISIBLE_DEVICES=0 \
VLLM_USE_V1=0 \
bash run_extraction.sh configs/sft_qwen35_9b.yaml \
  2>&1 | tee logs/qwen35_9b_pilot_$(date +%Y%m%d_%H%M%S).log
```

The pilot uses:

```yaml
data.sample_size: 50
runtime.batch_size: 16
concepts.normal_group_size: 42
concepts.long_post_group_size: 21
model.gpu_memory_utilization: 0.80
model.enforce_eager: true
```

If pilot OOMs, reduce `runtime.batch_size` to 8 first. Do not reduce concept group size first unless needed.

## Step 3: run full 4-GPU shard extraction

```bash
screen -S concepts_extraction_9b
```

Inside screen:

```bash
cd /mnt/disk1/wbjtu/tzbjtu/somental/psycbm
conda activate concepts
bash run_4gpu_shards.sh
```

Detach:

```text
Ctrl+A, then D
```

Monitor:

```bash
gpustat
tail -f logs/qwen35_9b_shard0_*.log
```

## Step 4: merge shard outputs

After all four jobs finish, list output folders:

```bash
ls -d outputs/qwen35_9b_concept_sft_lora_shard*__*
```

Then merge, replacing the folder names with the actual latest run folders:

```bash
python scripts/07_merge_shards.py \
  --runs \
    outputs/qwen35_9b_concept_sft_lora_shard0__YYYYMMDD_HHMMSS \
    outputs/qwen35_9b_concept_sft_lora_shard1__YYYYMMDD_HHMMSS \
    outputs/qwen35_9b_concept_sft_lora_shard2__YYYYMMDD_HHMMSS \
    outputs/qwen35_9b_concept_sft_lora_shard3__YYYYMMDD_HHMMSS \
  --out outputs/qwen35_9b_concept_sft_lora_merged
```

Merged files:

```text
outputs/qwen35_9b_concept_sft_lora_merged/concept_strength_matrix.csv
outputs/qwen35_9b_concept_sft_lora_merged/concept_evidence_matrix.csv
outputs/qwen35_9b_concept_sft_lora_merged/concept_not_sure_matrix.csv
outputs/qwen35_9b_concept_sft_lora_merged/shard_extraction_summaries.csv
```

## OOM risk notes

Most impactful settings:

```text
gpu_memory_utilization: direct memory reservation
max_model_len: KV-cache capacity pressure
batch_size: active prompts per worker
normal_group_size: prompt/output length per request
```

Recommended stable 9B starting point:

```yaml
gpu_memory_utilization: 0.80
max_model_len: 4096
batch_size: 16
normal_group_size: 42
long_post_group_size: 21
enforce_eager: true
```

Potential speed-up after pilot:

```yaml
runtime.batch_size: 24
model.gpu_memory_utilization: 0.85
```

OOM risk increases with both settings. Test on `sample_size: 50` before full extraction.
