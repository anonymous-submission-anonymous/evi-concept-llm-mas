from __future__ import annotations

from typing import Any, Dict, List, Optional

from transformers import AutoTokenizer
from vllm import LLM, SamplingParams

try:
    from vllm.lora.request import LoRARequest
except Exception:  # pragma: no cover - depends on vLLM version
    LoRARequest = None


def get_base_model_path(cfg: Dict[str, Any]) -> str:
    """Return the full HF base model path. Supports old `model_path` configs too."""
    model_cfg = cfg["model"]
    return str(model_cfg.get("base_model_path") or model_cfg.get("model_path"))


def load_tokenizer(cfg: Dict[str, Any]):
    """Load tokenizer from the base model, not from a LoRA adapter folder."""
    model_cfg = cfg["model"]
    return AutoTokenizer.from_pretrained(
        get_base_model_path(cfg),
        trust_remote_code=bool(model_cfg.get("trust_remote_code", True)),
    )


def messages_to_prompt(tokenizer, messages: List[Dict[str, str]], enable_thinking: bool = False) -> str:
    """Convert chat messages to a vLLM offline-generation prompt."""
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=enable_thinking,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )


def load_llm(cfg: Dict[str, Any]) -> LLM:
    """Load base model, optionally enabling a LoRA adapter at generation time."""
    model_cfg = cfg["model"]
    use_lora = bool(model_cfg.get("use_lora", False))

    llm_kwargs = dict(
        model=get_base_model_path(cfg),
        tensor_parallel_size=int(model_cfg.get("tensor_parallel_size", 1)),
        max_model_len=int(model_cfg.get("max_model_len", 4096)),
        gpu_memory_utilization=float(model_cfg.get("gpu_memory_utilization", 0.80)),
        trust_remote_code=bool(model_cfg.get("trust_remote_code", True)),
        dtype=str(model_cfg.get("dtype", "bfloat16")),
        enforce_eager=bool(model_cfg.get("enforce_eager", True)),
        disable_custom_all_reduce=bool(model_cfg.get("disable_custom_all_reduce", True)),
        enable_lora=use_lora,
    )

    if use_lora:
        llm_kwargs["max_loras"] = int(model_cfg.get("max_loras", 1))
        llm_kwargs["max_lora_rank"] = int(model_cfg.get("max_lora_rank", 16))

    print("vLLM kwargs:")
    for key, value in llm_kwargs.items():
        print(f"  {key}: {value}")

    return LLM(**llm_kwargs)


def build_sampling_params(cfg: Dict[str, Any]) -> SamplingParams:
    gen_cfg = cfg["generation"]
    return SamplingParams(
        temperature=float(gen_cfg.get("temperature", 0.0)),
        top_p=float(gen_cfg.get("top_p", 1.0)),
        max_tokens=int(gen_cfg.get("max_tokens", 1536)),
    )


def build_lora_request(cfg: Dict[str, Any]) -> Optional[LoRARequest]:
    model_cfg = cfg["model"]
    if not bool(model_cfg.get("use_lora", False)):
        return None

    if LoRARequest is None:
        raise RuntimeError("This vLLM installation does not expose LoRARequest. Check vLLM LoRA support.")

    adapter_path = model_cfg.get("lora_adapter_path")
    if not adapter_path:
        raise ValueError("use_lora=true but model.lora_adapter_path is missing.")

    return LoRARequest(
        lora_name=str(model_cfg.get("lora_name") or "concept_sft"),
        lora_int_id=int(model_cfg.get("lora_int_id", 1)),
        lora_path=str(adapter_path),
    )


def generate_batch(llm: LLM, prompts: List[str], sampling_params: SamplingParams, cfg: Dict[str, Any]):
    lora_request = build_lora_request(cfg)
    if lora_request is not None:
        return llm.generate(prompts, sampling_params, lora_request=lora_request)
    return llm.generate(prompts, sampling_params)
