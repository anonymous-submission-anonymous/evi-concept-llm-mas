from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def read_csv_if_exists(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        print(f"[skip missing] {path}")
        return None
    return pd.read_csv(path)


def concat_unique_csv(run_dirs: list[Path], relative_path: str, out_path: Path, sort_by_post_id: bool = True) -> None:
    frames = []
    for d in run_dirs:
        df = read_csv_if_exists(d / relative_path)
        if df is not None:
            df["_source_run_dir"] = d.name
            frames.append(df)
    if not frames:
        print(f"No input files found for {relative_path}")
        return
    out = pd.concat(frames, ignore_index=True)
    if "post_id" in out.columns:
        out = out.drop_duplicates(subset=["post_id"], keep="first")
        if sort_by_post_id:
            out = out.sort_values("post_id")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_path, index=False)
    print(f"saved {out_path} shape={out.shape}")


def main():
    parser = argparse.ArgumentParser(description="Merge outputs from 4 one-GPU 9B shard runs.")
    parser.add_argument("--runs", nargs="+", required=True, help="Shard run directories under outputs/ or absolute paths.")
    parser.add_argument("--out", required=True, help="Output directory for merged files.")
    args = parser.parse_args()

    run_dirs = [Path(x) for x in args.runs]
    out_dir = Path(args.out)

    concat_unique_csv(run_dirs, "matrices/concept_strength_matrix.csv", out_dir / "concept_strength_matrix.csv")
    concat_unique_csv(run_dirs, "matrices/concept_evidence_matrix.csv", out_dir / "concept_evidence_matrix.csv")
    concat_unique_csv(run_dirs, "matrices/concept_not_sure_matrix.csv", out_dir / "concept_not_sure_matrix.csv")

    # Reports are not row-level unique; keep with source run marker.
    report_frames = []
    for d in run_dirs:
        p = d / "reports/extraction_summary.csv"
        df = read_csv_if_exists(p)
        if df is not None:
            df["source_run_dir"] = d.name
            report_frames.append(df)
    if report_frames:
        out = pd.concat(report_frames, ignore_index=True)
        out_dir.mkdir(parents=True, exist_ok=True)
        out.to_csv(out_dir / "shard_extraction_summaries.csv", index=False)
        print(f"saved {out_dir / 'shard_extraction_summaries.csv'}")


if __name__ == "__main__":
    main()
