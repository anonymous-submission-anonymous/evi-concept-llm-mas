from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from utils.config import load_config_and_paths, parse_common_args
from utils.io_utils import ensure_dir, read_jsonl, write_jsonl
from utils.validation import validate_one_response


def main():
    args = parse_common_args()
    cfg, root, run_dir = load_config_and_paths(args.config, args.run_id)
    df = pd.read_csv(run_dir / 'prepared/input_prepared.csv')
    text_col = cfg['data']['text_col']
    post_text = dict(zip(df['post_id'].astype(str), df[text_col].astype(str)))

    raw_path = run_dir / 'raw_generations/raw_generations.jsonl'
    val_dir = ensure_dir(run_dir / 'validated')
    val_path = val_dir / 'validated_long.jsonl'
    err_path = val_dir / 'validation_errors.jsonl'
    report_path = val_dir / 'validation_report.json'

    rows_all, errors_all = [], []
    clear_invalid = bool(cfg['validation'].get('clear_invalid_evidence', True))

    for rec in tqdm(list(read_jsonl(raw_path)), desc='Validating'):
        pid = str(rec['post_id'])
        rows, errors = validate_one_response(
            raw_response=rec.get('raw_response', ''),
            post_id=pid,
            post_text=post_text.get(pid, ''),
            expected_concept_ids=rec['concept_ids'],
            model_name=rec['model_name'],
            group_id=rec['group_id'],
            clear_invalid_evidence=clear_invalid,
        )
        rows_all.extend(rows)
        errors_all.extend(errors)

    write_jsonl(rows_all, val_path)
    write_jsonl(errors_all, err_path)

    n = len(rows_all)
    report = {
        'n_validated_cells': n,
        'n_error_records': len(errors_all),
        'parse_invalid_cells': sum(not r['parse_valid'] for r in rows_all),
        'schema_invalid_cells': sum(not r['schema_valid'] for r in rows_all),
        'evidence_invalid_cells': sum(not r['evidence_valid'] for r in rows_all),
        'parse_invalid_rate': sum(not r['parse_valid'] for r in rows_all) / n if n else None,
        'schema_invalid_rate': sum(not r['schema_valid'] for r in rows_all) / n if n else None,
        'evidence_invalid_rate': sum(not r['evidence_valid'] for r in rows_all) / n if n else None,
    }
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print(f'Saved validated long file: {val_path}')
    print(f'Saved validation report: {report_path}')


if __name__ == '__main__':
    main()
