#!/usr/bin/env bash
set -euo pipefail
MODEL_DIR="${1:-/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3-Embedding-4B}"
mkdir -p "$(dirname "$MODEL_DIR")"

# Use HF mirror if you are in China / GitHub-HF network is unstable.
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"

python - <<PY
from huggingface_hub import snapshot_download
snapshot_download(
    repo_id="Qwen/Qwen3-Embedding-4B",
    local_dir="$MODEL_DIR",
    local_dir_use_symlinks=False,
    resume_download=True,
)
print("Saved to:", "$MODEL_DIR")
PY
