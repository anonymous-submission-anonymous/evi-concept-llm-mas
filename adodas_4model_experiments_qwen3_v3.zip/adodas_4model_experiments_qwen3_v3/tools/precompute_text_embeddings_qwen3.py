#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Precompute transcript embeddings for AdoDAS sessions using Qwen3-Embedding-4B.

Output .npz format consumed by the four model folders:
  ids: object array, shape (N,), value "SCH_xxx|CLS_xxxx|Pxxxx"
  embeddings: float32 array, shape (N, 4, D), session order A01/B01/B02/B03
  text_present: float32 array, shape (N, 4)
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from typing import Optional, Tuple, Dict
import numpy as np
import pandas as pd
from tqdm import tqdm

SESSIONS = ["A01", "B01", "B02", "B03"]


def parse_key(path: Path) -> Optional[Tuple[str, str, str]]:
    school = cls = pid = None
    for p in path.parts:
        if re.fullmatch(r"SCH[_-]?\d+", p, flags=re.I): school = p
        elif re.fullmatch(r"CLS[_-]?\d+", p, flags=re.I): cls = p
        elif re.fullmatch(r"P\d+", p, flags=re.I): pid = p
    return (str(school), str(cls), str(pid)) if school and cls and pid else None


def find_transcript_participants(root: Path) -> Dict[Tuple[str, str, str], Path]:
    out = {}
    for p in root.rglob("*"):
        if p.is_dir() and any((p / s).is_dir() for s in SESSIONS):
            k = parse_key(p)
            if k: out[k] = p
    return out


def safe_read(path: Path) -> str:
    if not path.exists(): return ""
    for enc in ["utf-8", "utf-8-sig", "gb18030", "latin1"]:
        try: return path.read_text(encoding=enc)
        except Exception: pass
    return ""


def load_transcript(troot: Optional[Path], sess: str) -> str:
    if troot is None: return ""
    d = troot / sess
    for name in ["clean_transcript.txt", "normalized_transcript.txt", "raw_transcript.txt"]:
        txt = safe_read(d / name).strip()
        if txt: return txt
    return ""


def guess_cols(df: pd.DataFrame):
    cols = {c.lower(): c for c in df.columns}
    def f(xs):
        for x in xs:
            if x in cols: return cols[x]
        return None
    return f(["anon_school","school","school_id"]), f(["anon_class","class","class_id","cls"]), f(["anon_pid","participant_id","pid","person_id","subject_id"])


def autodiscover_labels(root: Path) -> Optional[Path]:
    for p in root.rglob("*.csv"):
        if not any(x in p.name.lower() for x in ["label", "manifest", "a1", "train", "val"]):
            continue
        try:
            df = pd.read_csv(p, nrows=5)
            sc, cl, pid = guess_cols(df)
            if sc and cl and pid:
                return p
        except Exception:
            pass
    return None


def read_participant_keys(root: Path, labels_csv: Optional[Path]) -> list[Tuple[str,str,str]]:
    labels_csv = labels_csv or autodiscover_labels(root)
    if labels_csv is None:
        raise FileNotFoundError(f"No labels/manifest CSV found under {root}. Pass --labels-csv.")
    df = pd.read_csv(labels_csv)
    sc, cl, pid = guess_cols(df)
    if not all([sc, cl, pid]):
        raise ValueError(f"Could not detect participant columns in {labels_csv}; columns={list(df.columns)}")
    keys = [(str(r[sc]), str(r[cl]), str(r[pid])) for _, r in df.iterrows()]
    # preserve label order, remove duplicates
    seen = set(); out = []
    for k in keys:
        if k not in seen:
            out.append(k); seen.add(k)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", type=Path, required=True, help="train_unzip or val_unzip root")
    ap.add_argument("--labels-csv", type=Path, default=None)
    ap.add_argument("--model-path", type=str, required=True, help="local path, e.g. /mnt/.../Qwen3-Embedding-4B")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--max-seq-length", type=int, default=4096)
    ap.add_argument("--max-participants", type=int, default=0)
    ap.add_argument("--prompt", type=str, default="Represent this Chinese adolescent interview transcript for depression, anxiety, and stress prediction: ")
    args = ap.parse_args()

    from sentence_transformers import SentenceTransformer

    keys = read_participant_keys(args.data_root, args.labels_csv)
    if args.max_participants and args.max_participants > 0:
        keys = keys[:args.max_participants]
    tmap = find_transcript_participants(args.data_root)

    ids, texts, present = [], [], []
    for key in keys:
        pid = "|".join(key)
        ids.append(pid)
        troot = tmap.get(key)
        p_row = []
        for sess in SESSIONS:
            txt = load_transcript(troot, sess)
            p_row.append(1.0 if txt else 0.0)
            # Add session tag; helps Qwen distinguish B01/B02/B03.
            if txt:
                texts.append(f"{args.prompt} Session {sess}: {txt}")
            else:
                texts.append("")
        present.append(p_row)

    print(f"[INFO] participants: {len(ids)}")
    print(f"[INFO] total session texts: {len(texts)}")
    print(f"[INFO] loading model: {args.model_path}")
    model = SentenceTransformer(args.model_path, device=args.device, trust_remote_code=True)
    if args.max_seq_length:
        model.max_seq_length = args.max_seq_length

    emb = model.encode(
        texts,
        batch_size=args.batch_size,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,
    ).astype(np.float32)
    dim = emb.shape[-1]
    emb = emb.reshape(len(ids), len(SESSIONS), dim)
    present = np.asarray(present, dtype=np.float32)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out, ids=np.asarray(ids, dtype=object), embeddings=emb, text_present=present)
    meta = {
        "data_root": str(args.data_root),
        "labels_csv": str(args.labels_csv) if args.labels_csv else "auto",
        "model_path": args.model_path,
        "n_participants": len(ids),
        "sessions": SESSIONS,
        "embedding_dim": int(dim),
        "text_present_rate_by_session": {s: float(present[:, i].mean()) for i, s in enumerate(SESSIONS)},
        "prompt": args.prompt,
    }
    args.out.with_suffix(".meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[INFO] saved: {args.out}")
    print(json.dumps(meta, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
