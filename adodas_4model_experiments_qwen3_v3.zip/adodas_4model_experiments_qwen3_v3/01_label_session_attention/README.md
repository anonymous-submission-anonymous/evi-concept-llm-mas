# 01_label_session_attention

This model uses precomputed Qwen3-Embedding-4B transcript vectors if available at:

`cache/text_embeddings_train_qwen3_4b.npz`
`cache/text_embeddings_val_qwen3_4b.npz`

Run:

```bash
bash run.sh
```

Override embedding paths:

```bash
TRAIN_TEXT_EMB=/path/to/train_text.npz VAL_TEXT_EMB=/path/to/val_text.npz bash run.sh
```
