# AdoDAS A1 Four-Model Experiments with Qwen3 Transcript Embeddings

This package contains four independent runnable experiment folders.

Shared strategy for all four:

```text
multimodal-first A1 model
+ Qwen3-Embedding transcript branch
+ audio/video/eGeMAPS/quality features
+ participant-level Depression/Anxiety/Stress prediction
```

Each folder tests one unique strategy:

| Folder | Strategy |
|---|---|
| `01_label_session_attention` | Label-specific session attention |
| `02_ds_loss_corr_head` | D/S-aware loss + label-correlation head |
| `03_bottleneck_fusion` | Bottleneck multimodal fusion |
| `04_misa_quality_gates` | MISA-style common/private decomposition + quality gates |

Default data paths:

```bash
TRAIN_ROOT=/mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip
VAL_ROOT=/mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip
```

## 1. Install

```bash
conda activate adodas
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 2. Download Qwen3-Embedding-4B

Recommended local path:

```bash
/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3-Embedding-4B
```

Run:

```bash
bash tools/download_qwen3_embedding_4b.sh \
  /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3-Embedding-4B
```

## 3. Precompute transcript embeddings

Precompute once. Do not load Qwen3 during every training run.

```bash
MODEL=/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3-Embedding-4B

python tools/precompute_text_embeddings_qwen3.py \
  --data-root /mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip \
  --model-path "$MODEL" \
  --out cache/text_embeddings_train_qwen3_4b.npz \
  --batch-size 16 \
  --device cuda

python tools/precompute_text_embeddings_qwen3.py \
  --data-root /mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip \
  --model-path "$MODEL" \
  --out cache/text_embeddings_val_qwen3_4b.npz \
  --batch-size 16 \
  --device cuda
```

The output format is:

```text
ids:          (N,)      "SCH_xxx|CLS_xxxx|Pxxxx"
embeddings:   (N,4,2560) for A01/B01/B02/B03
text_present: (N,4)
```

## 4. Copy embeddings into each model folder

The configs expect embeddings inside each subfolder's `cache/` directory:

```bash
for d in 01_label_session_attention 02_ds_loss_corr_head 03_bottleneck_fusion 04_misa_quality_gates; do
  mkdir -p "$d/cache"
  cp cache/text_embeddings_train_qwen3_4b.npz "$d/cache/"
  cp cache/text_embeddings_val_qwen3_4b.npz "$d/cache/"
done
```

Or use environment variables instead:

```bash
export TRAIN_TEXT_EMB=/path/to/text_embeddings_train_qwen3_4b.npz
export VAL_TEXT_EMB=/path/to/text_embeddings_val_qwen3_4b.npz
```

## 5. Run all four models on 4 GPUs

```bash
bash run_all_4gpu.sh
```

## 6. Run one model

```bash
cd 01_label_session_attention
bash run.sh
```

If labels are not discovered automatically:

```bash
TRAIN_LABELS=/path/to/train_labels.csv \
VAL_LABELS=/path/to/val_labels.csv \
bash run.sh
```

## 7. Outputs

Each run saves:

```text
outputs/<timestamp>__<variant>/
├── config_used.json
├── input_dims.json
├── train_log.csv
├── best_metrics.json
├── val_predictions.csv
├── val_threshold_sweep.csv
├── val_best_thresholds.csv
├── val_confusion_by_label.csv
├── val_error_cases.csv
├── checkpoint_best.pt
└── strategy-specific diagnostics
```

Strategy-specific diagnostics:

```text
01_label_session_attention: val_session_attention.csv
02_ds_loss_corr_head:       val_label_correlation_residuals.csv
03_bottleneck_fusion:       val_bottleneck_diagnostics.csv
04_misa_quality_gates:      val_modality_gates.csv, train_aux_losses.csv
```

## 8. Important

This version **does not use n-gram hash vectors** when the Qwen3 `.npz` embedding files are present. If the embedding files are missing, the code can still fall back to hash vectors, but that is only for debugging.
