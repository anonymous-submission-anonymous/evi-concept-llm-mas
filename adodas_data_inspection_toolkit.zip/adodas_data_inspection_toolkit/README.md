# AdoDAS Data Inspection Toolkit

This toolkit is designed for **big-picture data inspection** before modifying the AdoDAS A1 model.

The goal is not only to check whether files exist. The goal is to answer:

> Which modality, session, feature group, and transcript source are reliable/useful enough to justify model enhancement?

It supports both **train** and **val** datasets.

---

## 1. Expected data structure

The toolkit assumes the AdoDAS feature data has participant folders like:

```text
/path/to/features/train/SCH_001/CLS_0015/P002949/
├── audio
│   ├── egemaps
│   ├── mel_mfcc
│   ├── ssl_embed
│   └── vad
└── video
    ├── body_pose
    ├── face_behavior
    ├── global_motion
    ├── headpose_geom
    ├── qc_stats
    ├── vad_agg
    └── vision_ssl_embed
```

The transcript data may look like:

```text
/path/to/transcripts/train/SCH_001/CLS_0015/P005682/
├── B01
│   ├── clean_transcript.txt
│   ├── meta.json
│   ├── normalized_transcript.txt
│   ├── raw_transcript.txt
│   ├── segments.csv
│   └── segments.json
├── B02
└── B03
```

Usually A1 sessions are:

```text
A01, B01, B02, B03
```

But transcripts may only exist for `B01/B02/B03`. This toolkit explicitly checks that.

---

## 2. What this toolkit produces

For each split, it creates:

```text
outputs/data_inspection_<split>/
├── 00_master_index.csv
├── 00_coverage_summary.csv
├── 02_feature_file_coverage.csv
├── 03_sequence_shape_stats.csv
├── 04_pooled_file_stats.csv
├── 05_transcript_stats.csv
├── 06_vad_transcript_alignment_stats.csv
├── 07_feature_distribution_stats.csv
├── 08_ssl_model_inventory.csv
├── report.md
└── figures/
    ├── session_coverage.png
    ├── transcript_length_by_session.png
    ├── sequence_length_by_feature.png
    └── missing_feature_heatmap.png
```

If you provide a labels CSV, it also creates:

```text
01_label_distribution.csv
01_label_cooccurrence.csv
figures/label_distribution.png
```

---

## 3. Installation

Activate your environment first:

```bash
conda activate adodas
```

Install required packages:

```bash
pip install -r requirements.txt
```

If your server uses a Tsinghua mirror:

```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

---

## 4. Quick start for train set

Example:

```bash
python scripts/inspect_adodas_data.py \
  --features-root /mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip/SCH_001/train \
  --transcript-root /mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip/train_transcript/train \
  --split-name train \
  --out-dir outputs/data_inspection_train
```

If your transcript root is different, change `--transcript-root`.

---

## 5. Quick start for val set

Example:

```bash
python scripts/inspect_adodas_data.py \
  --features-root /mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip/SCH_001/val \
  --transcript-root /mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip/val_transcript/val \
  --split-name val \
  --out-dir outputs/data_inspection_val
```

Adjust paths according to your real folder layout.

---

## 6. Optional: provide labels

If you have a CSV with participant labels, use:

```bash
python scripts/inspect_adodas_data.py \
  --features-root /path/to/features/train \
  --transcript-root /path/to/transcripts/train \
  --labels-csv /path/to/a1_train_labels.csv \
  --split-name train \
  --out-dir outputs/data_inspection_train
```

The script tries to auto-detect common columns:

Participant identity columns:

```text
anon_school, anon_class, anon_pid
school, class, pid
school_id, class_id, participant_id
```

A1 label columns:

```text
D, A, S
depression, anxiety, stress
label_D, label_A, label_S
y_D, y_A, y_S
```

If your columns are unusual, edit this function in `scripts/inspect_adodas_data.py`:

```python
guess_label_columns(df)
```

---

## 7. Recommended run commands

### Train

```bash
bash scripts/run_inspection.sh train \
  /mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip/SCH_001/train \
  /mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip/train_transcript/train \
  outputs/data_inspection_train
```

### Val

```bash
bash scripts/run_inspection.sh val \
  /mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip/SCH_001/val \
  /mnt/disk1/wbjtu/tzbjtu/adodas/val_unzip/val_transcript/val \
  outputs/data_inspection_val
```

With labels:

```bash
bash scripts/run_inspection.sh train \
  /path/to/features/train \
  /path/to/transcripts/train \
  outputs/data_inspection_train \
  /path/to/a1_train_labels.csv
```

---

## 8. How to read the outputs

### `00_master_index.csv`

One row per participant-session.

Important columns:

```text
school
class_id
participant_id
session
has_feature_root
has_transcript_root
has_audio_root
has_video_root
has_any_transcript
```

Use it to answer:

```text
How many participants do we have?
How many have all 4 feature sessions?
Do transcripts exist for A01 or only B01-B03?
Do train/val have similar coverage?
```

---

### `02_feature_file_coverage.csv`

One row per participant-session-feature.

Important columns:

```text
modality
feature_group
model_tag
has_sequence_npz
has_pooled_json
has_pooled_parquet
sequence_bytes
pooled_json_bytes
pooled_parquet_bytes
```

Use it to answer:

```text
Which baseline features are complete?
Are body_pose/global_motion complete enough to add?
Which SSL models are available and complete?
```

---

### `03_sequence_shape_stats.csv`

One row per sequence `.npz` file.

Important columns:

```text
n_frames
feature_dim
duration_sec_est
n_nan
n_inf
zero_ratio
mean_abs_value
std_value
npz_keys
```

Use it to answer:

```text
Are dimensions correct?
Are there NaN/Inf bugs?
Are many sessions too short?
Are some feature groups almost all zeros?
```

---

### `05_transcript_stats.csv`

One row per participant-session transcript.

Important columns:

```text
has_raw_transcript
has_clean_transcript
has_normalized_transcript
raw_char_count
clean_char_count
normalized_char_count
clean_token_count
segment_count_csv
segment_count_json
empty_clean_transcript
```

Use it to answer:

```text
Are transcripts complete?
Are they only available for B sessions?
Is clean_transcript usable?
Do we need normalized_transcript?
Is text long enough to justify a text branch?
```

---

### `06_vad_transcript_alignment_stats.csv`

One row per participant-session if both VAD and transcript segment files exist.

Important columns:

```text
audio_vad_speech_sec
transcript_segment_sec
duration_diff_sec
duration_diff_ratio
n_audio_segments
n_transcript_segments
```

Use it to answer:

```text
Can we do segment-level audio-text fusion?
Or should we only do session-level text embedding?
```

---

## 9. How this informs model enhancement

### Enhancement A: Add transcript branch

Use this if:

```text
05_transcript_stats.csv shows good transcript coverage
clean/normalized transcript length is non-trivial
alignment is acceptable or session-level text is enough
```

Minimal model change:

```text
clean_transcript or normalized_transcript
→ Chinese text encoder
→ session text embedding
→ concatenate with [audio ASP, video ASP, eGeMAPS, session embedding]
```

Current fusion input:

```text
[z_audio, z_video, z_egemaps, z_session]
```

Enhanced fusion input:

```text
[z_audio, z_video, z_egemaps, z_text, z_session]
```

---

### Enhancement B: Add session attention aggregator

Use this if:

```text
B01/B02/B03 have very different coverage/quality/length
one session type seems much stronger or cleaner
A01 is missing text or weak
```

Current aggregator:

```text
masked mean over A01/B01/B02/B03 → MLP
```

Better aggregator:

```text
session attention over 4 session vectors
```

Formula:

```text
alpha_s = softmax(w^T h_s)
h_participant = sum_s alpha_s h_s
```

---

### Enhancement C: Add quality-aware modality gating

Use this if:

```text
video QC varies heavily
many sessions have poor face detection
speech ratio varies heavily
some modalities are missing/noisy
```

Idea:

```text
use VAD/QC summary to compute audio/video gates
```

Formula:

```text
g_audio = sigmoid(W_audio q_audio)
g_video = sigmoid(W_video q_video)

z_fused = [g_audio * z_audio, g_video * z_video, z_egemaps, z_text, z_session]
```

---

### Enhancement D: Add unused video features

Use this if:

```text
body_pose and global_motion coverage is high
shape checks are clean
pooled probes show signal
```

Then modify A1 config:

```yaml
video_features:
  - headpose_geom
  - face_behavior
  - qc_stats
  - vad_agg
  - body_pose
  - global_motion
  - vision_ssl_embed
```

---

### Enhancement E: Compare SSL model choices

The data contains multiple audio/vision SSL models. The baseline uses:

```text
audio: wav2vec2-chinese-xlsr
video: dinov2-large
```

But your feature tree may include:

```text
audio SSL:
  chinese-hubert-base
  chinese-hubert-large
  chinese-wav2vec2-base
  chinese-wav2vec2-large
  wav2vec2-chinese-xlsr
  wavlm-base

vision SSL:
  dinov2-base
  dinov2-large
  dinov2-small
  siglip-base-patch16-224
  siglip-so400m-patch14-384
  vit-base-patch16-224
  vit-mae-base
```

Use `08_ssl_model_inventory.csv` to see which are complete enough to compare.

---

## 10. Notes for Claude Code

Suggested prompt for Claude Code:

```text
Read this repository. The main script is scripts/inspect_adodas_data.py.
I want to modify it for my AdoDAS train/val dataset.
First inspect the argument parser and data traversal logic.
Then update the root path detection if my folder structure differs.
Do not change the output CSV schema unless necessary.
Add small functions rather than putting everything in main().
```

Good modification targets:

```text
1. labels CSV column detection
2. custom transcript tokenization
3. adding participant-level pooled probes
4. adding LightGBM/logistic-regression probes
5. adding more plots
6. adding support for a new transcript folder layout
```

---

## 11. Common problems and fixes

### Problem: no participant folders found

Check whether your `--features-root` points to the folder **above** `SCH_001`.

Correct:

```text
/path/to/train/SCH_001/CLS_0015/P002949/audio
```

Then use:

```bash
--features-root /path/to/train
```

Not:

```bash
--features-root /path/to/train/SCH_001/CLS_0015/P002949
```

---

### Problem: transcript coverage is zero

Your transcript root may be wrong. It should point to the folder above `SCH_001`.

Correct:

```text
/path/to/train_transcript/train/SCH_001/CLS_0015/P005682/B01/clean_transcript.txt
```

Then use:

```bash
--transcript-root /path/to/train_transcript/train
```

---

### Problem: script is slow

Use sampling first:

```bash
python scripts/inspect_adodas_data.py \
  --features-root /path/to/features/train \
  --transcript-root /path/to/transcripts/train \
  --split-name train \
  --out-dir outputs/data_inspection_train_sample \
  --max-participants 200
```

Then run full after confirming paths are correct.

---

## 12. Next recommended step

Run train and val inspections separately:

```bash
bash scripts/run_inspection.sh train /path/to/features/train /path/to/transcripts/train outputs/data_inspection_train
bash scripts/run_inspection.sh val   /path/to/features/val   /path/to/transcripts/val   outputs/data_inspection_val
```

Then compare:

```text
train vs val label distribution
train vs val session coverage
train vs val transcript length
train vs val feature missingness
train vs val sequence lengths
```

If they differ strongly, model validation may be unstable and you should prefer robust model changes, not complex ones.
