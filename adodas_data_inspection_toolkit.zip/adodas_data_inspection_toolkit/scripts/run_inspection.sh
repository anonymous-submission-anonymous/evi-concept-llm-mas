#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   bash scripts/run_inspection.sh <split_name> <features_root> <transcript_root> <out_dir> [labels_csv]
#
# Example:
#   bash scripts/run_inspection.sh train \
#     /mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip/SCH_001/train \
#     /mnt/disk1/wbjtu/tzbjtu/adodas/train_unzip/train_transcript/train \
#     outputs/data_inspection_train

SPLIT_NAME="${1:?split_name required, e.g. train or val}"
FEATURES_ROOT="${2:?features_root required}"
TRANSCRIPT_ROOT="${3:?transcript_root required}"
OUT_DIR="${4:?out_dir required}"
LABELS_CSV="${5:-}"

CMD=(python scripts/inspect_adodas_data.py
  --features-root "$FEATURES_ROOT"
  --transcript-root "$TRANSCRIPT_ROOT"
  --split-name "$SPLIT_NAME"
  --out-dir "$OUT_DIR"
)

if [[ -n "$LABELS_CSV" ]]; then
  CMD+=(--labels-csv "$LABELS_CSV")
fi

echo "[INFO] Running:"
printf ' %q' "${CMD[@]}"
echo

"${CMD[@]}"
