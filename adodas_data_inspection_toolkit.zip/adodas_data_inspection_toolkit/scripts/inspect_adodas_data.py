#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
AdoDAS data inspection script.

Purpose:
  Inspect train/val feature and transcript data before model enhancement.

Outputs:
  - master participant/session index
  - feature coverage
  - sequence shape and quality statistics
  - pooled file statistics
  - transcript statistics
  - VAD/transcript alignment statistics
  - SSL model inventory
  - basic figures
  - markdown report

This script intentionally avoids training any model. It is for data diagnosis.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Any

import numpy as np
import pandas as pd
from tqdm import tqdm

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


SESSIONS = ["A01", "B01", "B02", "B03"]

BASELINE_AUDIO_SSL = "wav2vec2-chinese-xlsr"
BASELINE_VISION_SSL = "dinov2-large"

AUDIO_SSL_MODELS = [
    "chinese-hubert-base",
    "chinese-hubert-large",
    "chinese-wav2vec2-base",
    "chinese-wav2vec2-large",
    "wav2vec2-chinese-xlsr",
    "wavlm-base",
]

VISION_SSL_MODELS = [
    "dinov2-base",
    "dinov2-large",
    "dinov2-small",
    "siglip-base-patch16-224",
    "siglip-so400m-patch14-384",
    "vit-base-patch16-224",
    "vit-mae-base",
]


@dataclass(frozen=True)
class ParticipantKey:
    school: str
    class_id: str
    participant_id: str

    def as_tuple(self) -> Tuple[str, str, str]:
        return (self.school, self.class_id, self.participant_id)


@dataclass
class ParticipantPaths:
    key: ParticipantKey
    feature_dir: Optional[Path] = None
    transcript_dir: Optional[Path] = None


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def is_participant_dir(path: Path, mode: str) -> bool:
    """Detect participant directory.

    Feature participant dir usually has audio/video.
    Transcript participant dir usually has B01/B02/B03 session folders.
    """
    if not path.is_dir():
        return False

    if mode == "features":
        return (path / "audio").is_dir() or (path / "video").is_dir()

    if mode == "transcripts":
        return any((path / s).is_dir() for s in SESSIONS)

    raise ValueError(f"Unknown mode: {mode}")


def parse_participant_key(path: Path) -> Optional[ParticipantKey]:
    """Parse SCH_xxx/CLS_xxxx/Pxxxx from path parts."""
    parts = path.parts
    school = None
    cls = None
    pid = None
    for p in parts:
        if re.fullmatch(r"SCH[_-]?\d+", p, flags=re.IGNORECASE):
            school = p
        elif re.fullmatch(r"CLS[_-]?\d+", p, flags=re.IGNORECASE):
            cls = p
        elif re.fullmatch(r"P\d+", p, flags=re.IGNORECASE):
            pid = p
    if school and cls and pid:
        return ParticipantKey(school, cls, pid)
    return None


def find_participants(root: Optional[Path], mode: str) -> Dict[ParticipantKey, Path]:
    if root is None or not root.exists():
        return {}

    found: Dict[ParticipantKey, Path] = {}
    for p in root.rglob("*"):
        if not is_participant_dir(p, mode=mode):
            continue
        key = parse_participant_key(p)
        if key is not None:
            found[key] = p
    return found


def limit_participants(keys: List[ParticipantKey], max_participants: Optional[int]) -> List[ParticipantKey]:
    keys = sorted(keys, key=lambda k: k.as_tuple())
    if max_participants is not None and max_participants > 0:
        return keys[:max_participants]
    return keys


def make_participant_paths(
    features_root: Optional[Path],
    transcript_root: Optional[Path],
    max_participants: Optional[int] = None,
) -> List[ParticipantPaths]:
    feature_map = find_participants(features_root, mode="features")
    transcript_map = find_participants(transcript_root, mode="transcripts")

    all_keys = sorted(set(feature_map.keys()) | set(transcript_map.keys()), key=lambda k: k.as_tuple())
    all_keys = limit_participants(all_keys, max_participants)

    rows = []
    for key in all_keys:
        rows.append(
            ParticipantPaths(
                key=key,
                feature_dir=feature_map.get(key),
                transcript_dir=transcript_map.get(key),
            )
        )
    return rows


def file_size(path: Path) -> int:
    try:
        return path.stat().st_size
    except Exception:
        return 0


def safe_read_text(path: Path) -> str:
    if not path.exists():
        return ""
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin1"):
        try:
            return path.read_text(encoding=enc)
        except Exception:
            pass
    return ""


def safe_json_load(path: Path) -> Any:
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        try:
            with path.open("r", encoding="utf-8-sig") as f:
                return json.load(f)
        except Exception:
            return None


def safe_read_csv_len(path: Path) -> int:
    if not path.exists():
        return 0
    try:
        df = pd.read_csv(path)
        return len(df)
    except Exception:
        try:
            df = pd.read_csv(path, encoding="utf-8-sig")
            return len(df)
        except Exception:
            return 0


def count_tokens_simple(text: str) -> int:
    """Simple tokenizer good enough for inspection.

    For Chinese text, character count may be more meaningful than whitespace tokens.
    This returns:
      - whitespace token count if spaces exist
      - otherwise number of CJK/letter/digit character groups
    """
    text = text.strip()
    if not text:
        return 0
    if re.search(r"\s", text):
        return len([t for t in re.split(r"\s+", text) if t])
    # Approximate Chinese text length by non-punctuation chars.
    chars = re.findall(r"[\w\u4e00-\u9fff]", text)
    return len(chars)


def transcript_duration_from_segments_json(path: Path) -> Tuple[float, int]:
    data = safe_json_load(path)
    if data is None:
        return (0.0, 0)

    segments = None
    if isinstance(data, list):
        segments = data
    elif isinstance(data, dict):
        for key in ["segments", "speech_segments", "items"]:
            if isinstance(data.get(key), list):
                segments = data[key]
                break

    if not segments:
        return (0.0, 0)

    total = 0.0
    n = 0
    for seg in segments:
        if not isinstance(seg, dict):
            continue
        start = seg.get("start", seg.get("start_time", seg.get("begin", None)))
        end = seg.get("end", seg.get("end_time", seg.get("stop", None)))
        try:
            if start is not None and end is not None:
                dur = float(end) - float(start)
                if dur > 0:
                    total += dur
                    n += 1
        except Exception:
            continue
    return (total, n)


def transcript_duration_from_segments_csv(path: Path) -> Tuple[float, int]:
    if not path.exists():
        return (0.0, 0)
    try:
        df = pd.read_csv(path)
    except Exception:
        try:
            df = pd.read_csv(path, encoding="utf-8-sig")
        except Exception:
            return (0.0, 0)

    lower_cols = {c.lower(): c for c in df.columns}
    start_col = None
    end_col = None
    for cand in ["start", "start_time", "begin"]:
        if cand in lower_cols:
            start_col = lower_cols[cand]
            break
    for cand in ["end", "end_time", "stop"]:
        if cand in lower_cols:
            end_col = lower_cols[cand]
            break

    if start_col is None or end_col is None:
        return (0.0, len(df))

    starts = pd.to_numeric(df[start_col], errors="coerce")
    ends = pd.to_numeric(df[end_col], errors="coerce")
    dur = (ends - starts).clip(lower=0)
    return (float(dur.sum(skipna=True)), int(dur.notna().sum()))


def vad_duration_from_segments_json(path: Path) -> Tuple[float, int]:
    # Same parser works for many VAD segment JSON formats.
    return transcript_duration_from_segments_json(path)


def inspect_master_index(participants: List[ParticipantPaths]) -> pd.DataFrame:
    rows = []
    for pp in participants:
        for sess in SESSIONS:
            f_sess_exists = False
            t_sess_exists = False
            has_audio = False
            has_video = False

            if pp.feature_dir:
                has_audio = (pp.feature_dir / "audio").exists()
                has_video = (pp.feature_dir / "video").exists()
                # A feature session may exist in any feature folder.
                f_sess_exists = any(pp.feature_dir.glob(f"audio/*/{sess}")) or any(pp.feature_dir.glob(f"video/*/{sess}"))

            if pp.transcript_dir:
                t_sess_exists = (pp.transcript_dir / sess).is_dir()

            rows.append({
                "school": pp.key.school,
                "class_id": pp.key.class_id,
                "participant_id": pp.key.participant_id,
                "session": sess,
                "has_feature_root": pp.feature_dir is not None,
                "has_transcript_root": pp.transcript_dir is not None,
                "has_audio_root": has_audio,
                "has_video_root": has_video,
                "has_feature_session": f_sess_exists,
                "has_transcript_session": t_sess_exists,
                "feature_dir": str(pp.feature_dir) if pp.feature_dir else "",
                "transcript_dir": str(pp.transcript_dir) if pp.transcript_dir else "",
            })
    return pd.DataFrame(rows)


def feature_specs_for_session(pp: ParticipantPaths, sess: str) -> List[Dict[str, Any]]:
    """Return expected/available feature paths for one participant-session."""
    if pp.feature_dir is None:
        return []

    base = pp.feature_dir
    specs: List[Dict[str, Any]] = []

    # Non-SSL audio/video features.
    simple_specs = [
        ("audio", "egemaps", None, base / "audio" / "egemaps" / sess),
        ("audio", "mel_mfcc", None, base / "audio" / "mel_mfcc" / sess),
        ("audio", "vad", None, base / "audio" / "vad" / sess),
        ("video", "body_pose", None, base / "video" / "body_pose" / sess),
        ("video", "face_behavior", None, base / "video" / "face_behavior" / sess),
        ("video", "global_motion", None, base / "video" / "global_motion" / sess),
        ("video", "headpose_geom", None, base / "video" / "headpose_geom" / sess),
        ("video", "qc_stats", None, base / "video" / "qc_stats" / sess),
        ("video", "vad_agg", None, base / "video" / "vad_agg" / sess),
    ]

    for modality, group, tag, d in simple_specs:
        specs.append({
            "modality": modality,
            "feature_group": group,
            "model_tag": tag or "",
            "dir": d,
        })

    # SSL features with model tags.
    ssl_root = base / "audio" / "ssl_embed"
    if ssl_root.exists():
        tags = sorted([p.name for p in ssl_root.iterdir() if p.is_dir()])
    else:
        tags = AUDIO_SSL_MODELS
    for tag in tags:
        specs.append({
            "modality": "audio",
            "feature_group": "ssl_embed",
            "model_tag": tag,
            "dir": ssl_root / tag / sess,
        })

    vssl_root = base / "video" / "vision_ssl_embed"
    if vssl_root.exists():
        tags = sorted([p.name for p in vssl_root.iterdir() if p.is_dir()])
    else:
        tags = VISION_SSL_MODELS
    for tag in tags:
        specs.append({
            "modality": "video",
            "feature_group": "vision_ssl_embed",
            "model_tag": tag,
            "dir": vssl_root / tag / sess,
        })

    return specs


def inspect_feature_coverage(participants: List[ParticipantPaths]) -> pd.DataFrame:
    rows = []
    for pp in tqdm(participants, desc="feature coverage"):
        for sess in SESSIONS:
            for spec in feature_specs_for_session(pp, sess):
                d = Path(spec["dir"])
                seq = d / "sequence.npz"
                pooled_json = d / "pooled.json"
                pooled_parquet = d / "pooled.parquet"
                segments_json = d / "segments.json"

                rows.append({
                    "school": pp.key.school,
                    "class_id": pp.key.class_id,
                    "participant_id": pp.key.participant_id,
                    "session": sess,
                    "modality": spec["modality"],
                    "feature_group": spec["feature_group"],
                    "model_tag": spec["model_tag"],
                    "feature_dir_exists": d.is_dir(),
                    "has_sequence_npz": seq.exists(),
                    "has_pooled_json": pooled_json.exists(),
                    "has_pooled_parquet": pooled_parquet.exists(),
                    "has_segments_json": segments_json.exists(),
                    "sequence_bytes": file_size(seq),
                    "pooled_json_bytes": file_size(pooled_json),
                    "pooled_parquet_bytes": file_size(pooled_parquet),
                    "segments_json_bytes": file_size(segments_json),
                    "feature_dir": str(d),
                })
    return pd.DataFrame(rows)


def choose_feature_array(npz: np.lib.npyio.NpzFile, feature_group: str) -> Tuple[Optional[np.ndarray], str]:
    keys = list(npz.keys())

    if feature_group == "mel_mfcc" and "mel_features" in keys and "mfcc_features" in keys:
        mel = npz["mel_features"]
        mfcc = npz["mfcc_features"]
        if mel.ndim == 2 and mfcc.ndim == 2 and mel.shape[0] == mfcc.shape[0]:
            return np.concatenate([mel, mfcc], axis=1), "concat(mel_features,mfcc_features)"

    for k in ["features", "feature", "embeddings", "embedding", "values", "data", "x"]:
        if k in keys:
            arr = npz[k]
            if isinstance(arr, np.ndarray) and arr.ndim >= 1:
                return arr, k

    # Fallback: first numeric ndarray with ndim >= 1 and not timestamps.
    for k in keys:
        if "time" in k.lower() or "timestamp" in k.lower():
            continue
        arr = npz[k]
        if isinstance(arr, np.ndarray) and arr.ndim >= 1 and np.issubdtype(arr.dtype, np.number):
            return arr, k

    return None, ""


def choose_timestamps(npz: np.lib.npyio.NpzFile) -> Optional[np.ndarray]:
    keys = list(npz.keys())
    for k in ["timestamps", "timestamp", "times", "time", "t"]:
        if k in keys:
            arr = npz[k]
            if isinstance(arr, np.ndarray) and arr.ndim == 1:
                return arr
    return None


def inspect_sequence_file(row: pd.Series) -> Dict[str, Any]:
    path = Path(row["feature_dir"]) / "sequence.npz"
    result = {
        "school": row["school"],
        "class_id": row["class_id"],
        "participant_id": row["participant_id"],
        "session": row["session"],
        "modality": row["modality"],
        "feature_group": row["feature_group"],
        "model_tag": row["model_tag"],
        "sequence_path": str(path),
        "read_ok": False,
        "npz_keys": "",
        "array_key": "",
        "ndim": np.nan,
        "n_frames": np.nan,
        "feature_dim": np.nan,
        "duration_sec_est": np.nan,
        "n_nan": np.nan,
        "n_inf": np.nan,
        "zero_ratio": np.nan,
        "mean_abs_value": np.nan,
        "std_value": np.nan,
        "error": "",
    }
    if not path.exists():
        result["error"] = "missing"
        return result

    try:
        with np.load(path, allow_pickle=False) as npz:
            keys = list(npz.keys())
            result["npz_keys"] = ",".join(keys)
            arr, arr_key = choose_feature_array(npz, str(row["feature_group"]))
            result["array_key"] = arr_key
            if arr is None:
                result["error"] = "no_numeric_feature_array"
                return result

            arr = np.asarray(arr)
            result["read_ok"] = True
            result["ndim"] = arr.ndim

            if arr.ndim == 1:
                n_frames = arr.shape[0]
                feat_dim = 1
            else:
                n_frames = arr.shape[0]
                feat_dim = int(np.prod(arr.shape[1:]))

            result["n_frames"] = n_frames
            result["feature_dim"] = feat_dim

            ts = choose_timestamps(npz)
            if ts is not None and len(ts) >= 2:
                try:
                    result["duration_sec_est"] = float(np.nanmax(ts) - np.nanmin(ts))
                except Exception:
                    pass
            elif n_frames and not math.isnan(n_frames):
                # Many aligned features are around 25 Hz.
                result["duration_sec_est"] = float(n_frames) / 25.0

            flat = arr.astype(np.float64, copy=False).reshape(-1)
            result["n_nan"] = int(np.isnan(flat).sum())
            result["n_inf"] = int(np.isinf(flat).sum())
            finite = flat[np.isfinite(flat)]
            if finite.size > 0:
                result["zero_ratio"] = float(np.mean(finite == 0))
                result["mean_abs_value"] = float(np.mean(np.abs(finite)))
                result["std_value"] = float(np.std(finite))
            else:
                result["zero_ratio"] = np.nan
                result["mean_abs_value"] = np.nan
                result["std_value"] = np.nan

    except Exception as e:
        result["error"] = repr(e)

    return result


def inspect_sequence_stats(feature_cov: pd.DataFrame) -> pd.DataFrame:
    if feature_cov.empty:
        return pd.DataFrame()
    seq_rows = feature_cov[feature_cov["has_sequence_npz"] == True].copy()
    results = []
    for _, row in tqdm(seq_rows.iterrows(), total=len(seq_rows), desc="sequence stats"):
        results.append(inspect_sequence_file(row))
    return pd.DataFrame(results)


def inspect_pooled_stats(feature_cov: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if feature_cov.empty:
        return pd.DataFrame()

    pooled_rows = feature_cov[
        (feature_cov["has_pooled_json"] == True) | (feature_cov["has_pooled_parquet"] == True)
    ].copy()

    for _, row in tqdm(pooled_rows.iterrows(), total=len(pooled_rows), desc="pooled stats"):
        d = Path(row["feature_dir"])
        rec = {
            "school": row["school"],
            "class_id": row["class_id"],
            "participant_id": row["participant_id"],
            "session": row["session"],
            "modality": row["modality"],
            "feature_group": row["feature_group"],
            "model_tag": row["model_tag"],
            "has_pooled_json": bool(row["has_pooled_json"]),
            "has_pooled_parquet": bool(row["has_pooled_parquet"]),
            "n_values_json": np.nan,
            "n_columns_parquet": np.nan,
            "n_rows_parquet": np.nan,
            "json_numeric_count": np.nan,
            "json_numeric_mean_abs": np.nan,
            "json_error": "",
            "parquet_error": "",
        }

        pj = d / "pooled.json"
        if pj.exists():
            data = safe_json_load(pj)
            try:
                nums = []
                def collect(x):
                    if isinstance(x, (int, float)) and np.isfinite(x):
                        nums.append(float(x))
                    elif isinstance(x, dict):
                        for v in x.values():
                            collect(v)
                    elif isinstance(x, list):
                        for v in x:
                            collect(v)
                collect(data)
                rec["n_values_json"] = len(data) if isinstance(data, (dict, list)) else 1
                rec["json_numeric_count"] = len(nums)
                rec["json_numeric_mean_abs"] = float(np.mean(np.abs(nums))) if nums else np.nan
            except Exception as e:
                rec["json_error"] = repr(e)

        pp = d / "pooled.parquet"
        if pp.exists():
            try:
                df = pd.read_parquet(pp)
                rec["n_columns_parquet"] = len(df.columns)
                rec["n_rows_parquet"] = len(df)
            except Exception as e:
                rec["parquet_error"] = repr(e)

        rows.append(rec)

    return pd.DataFrame(rows)


def inspect_transcripts(participants: List[ParticipantPaths]) -> pd.DataFrame:
    rows = []
    for pp in tqdm(participants, desc="transcripts"):
        for sess in SESSIONS:
            d = pp.transcript_dir / sess if pp.transcript_dir else None
            rec = {
                "school": pp.key.school,
                "class_id": pp.key.class_id,
                "participant_id": pp.key.participant_id,
                "session": sess,
                "transcript_dir": str(d) if d else "",
                "has_transcript_session": bool(d and d.is_dir()),
                "has_raw_transcript": False,
                "has_clean_transcript": False,
                "has_normalized_transcript": False,
                "has_meta_json": False,
                "has_segments_csv": False,
                "has_segments_json": False,
                "raw_char_count": 0,
                "clean_char_count": 0,
                "normalized_char_count": 0,
                "raw_token_count": 0,
                "clean_token_count": 0,
                "normalized_token_count": 0,
                "empty_clean_transcript": True,
                "segment_count_csv": 0,
                "segment_count_json": 0,
                "segment_duration_csv_sec": 0.0,
                "segment_duration_json_sec": 0.0,
                "meta_keys": "",
            }

            if not d or not d.is_dir():
                rows.append(rec)
                continue

            raw = d / "raw_transcript.txt"
            clean = d / "clean_transcript.txt"
            norm = d / "normalized_transcript.txt"
            meta = d / "meta.json"
            seg_csv = d / "segments.csv"
            seg_json = d / "segments.json"

            rec["has_raw_transcript"] = raw.exists()
            rec["has_clean_transcript"] = clean.exists()
            rec["has_normalized_transcript"] = norm.exists()
            rec["has_meta_json"] = meta.exists()
            rec["has_segments_csv"] = seg_csv.exists()
            rec["has_segments_json"] = seg_json.exists()

            raw_text = safe_read_text(raw)
            clean_text = safe_read_text(clean)
            norm_text = safe_read_text(norm)

            rec["raw_char_count"] = len(raw_text)
            rec["clean_char_count"] = len(clean_text)
            rec["normalized_char_count"] = len(norm_text)
            rec["raw_token_count"] = count_tokens_simple(raw_text)
            rec["clean_token_count"] = count_tokens_simple(clean_text)
            rec["normalized_token_count"] = count_tokens_simple(norm_text)
            rec["empty_clean_transcript"] = len(clean_text.strip()) == 0

            dur_csv, n_csv = transcript_duration_from_segments_csv(seg_csv)
            dur_json, n_json = transcript_duration_from_segments_json(seg_json)
            rec["segment_count_csv"] = n_csv if n_csv else safe_read_csv_len(seg_csv)
            rec["segment_count_json"] = n_json
            rec["segment_duration_csv_sec"] = dur_csv
            rec["segment_duration_json_sec"] = dur_json

            meta_data = safe_json_load(meta)
            if isinstance(meta_data, dict):
                rec["meta_keys"] = ",".join(sorted(meta_data.keys()))

            rows.append(rec)
    return pd.DataFrame(rows)


def inspect_vad_transcript_alignment(participants: List[ParticipantPaths]) -> pd.DataFrame:
    rows = []
    for pp in tqdm(participants, desc="vad-transcript alignment"):
        for sess in SESSIONS:
            if pp.feature_dir is None or pp.transcript_dir is None:
                continue
            vad_seg = pp.feature_dir / "audio" / "vad" / sess / "segments.json"
            tr_csv = pp.transcript_dir / sess / "segments.csv"
            tr_json = pp.transcript_dir / sess / "segments.json"

            audio_vad_sec, n_audio = vad_duration_from_segments_json(vad_seg)
            tr_csv_sec, n_csv = transcript_duration_from_segments_csv(tr_csv)
            tr_json_sec, n_json = transcript_duration_from_segments_json(tr_json)

            tr_sec = tr_json_sec if tr_json_sec > 0 else tr_csv_sec
            n_tr = n_json if n_json > 0 else n_csv

            if not vad_seg.exists() and not tr_csv.exists() and not tr_json.exists():
                continue

            diff = audio_vad_sec - tr_sec
            denom = max(audio_vad_sec, tr_sec, 1e-6)
            rows.append({
                "school": pp.key.school,
                "class_id": pp.key.class_id,
                "participant_id": pp.key.participant_id,
                "session": sess,
                "has_audio_vad_segments": vad_seg.exists(),
                "has_transcript_segments_csv": tr_csv.exists(),
                "has_transcript_segments_json": tr_json.exists(),
                "audio_vad_speech_sec": audio_vad_sec,
                "transcript_segment_sec": tr_sec,
                "duration_diff_sec": diff,
                "duration_diff_ratio": diff / denom,
                "n_audio_segments": n_audio,
                "n_transcript_segments": n_tr,
            })
    return pd.DataFrame(rows)


def guess_label_columns(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], Optional[str], Optional[str]]:
    cols = {c.lower(): c for c in df.columns}

    school = None
    cls = None
    pid = None
    for cand in ["anon_school", "school", "school_id"]:
        if cand in cols:
            school = cols[cand]
            break
    for cand in ["anon_class", "class", "class_id", "cls"]:
        if cand in cols:
            cls = cols[cand]
            break
    for cand in ["anon_pid", "participant_id", "pid", "person_id", "subject_id"]:
        if cand in cols:
            pid = cols[cand]
            break

    def find_label(cands):
        for cand in cands:
            if cand in cols:
                return cols[cand]
        return None

    d = find_label(["d", "depression", "label_d", "y_d", "dep", "depression_label"])
    a = find_label(["a", "anxiety", "label_a", "y_a", "anx", "anxiety_label"])
    s = find_label(["s", "stress", "label_s", "y_s", "str", "stress_label"])
    return school, cls, pid, d, a, s


def inspect_labels(labels_csv: Optional[Path], master: pd.DataFrame, out_dir: Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if labels_csv is None or not labels_csv.exists():
        return pd.DataFrame(), pd.DataFrame(), master

    labels = pd.read_csv(labels_csv)
    school_col, cls_col, pid_col, d_col, a_col, s_col = guess_label_columns(labels)

    if not all([school_col, cls_col, pid_col, d_col, a_col, s_col]):
        warning = pd.DataFrame([{
            "error": "Could not auto-detect label columns.",
            "columns": ",".join(labels.columns),
            "detected_school": school_col or "",
            "detected_class": cls_col or "",
            "detected_pid": pid_col or "",
            "detected_D": d_col or "",
            "detected_A": a_col or "",
            "detected_S": s_col or "",
        }])
        warning.to_csv(out_dir / "01_label_column_detection_warning.csv", index=False)
        return pd.DataFrame(), pd.DataFrame(), master

    lab = labels[[school_col, cls_col, pid_col, d_col, a_col, s_col]].copy()
    lab.columns = ["school", "class_id", "participant_id", "label_D", "label_A", "label_S"]
    for c in ["school", "class_id", "participant_id"]:
        lab[c] = lab[c].astype(str)

    # Merge labels into master index.
    master2 = master.merge(lab, on=["school", "class_id", "participant_id"], how="left")

    dist_rows = []
    for target in ["label_D", "label_A", "label_S"]:
        counts = lab[target].value_counts(dropna=False).to_dict()
        dist_rows.append({
            "target": target,
            "n_0": counts.get(0, counts.get("0", 0)),
            "n_1": counts.get(1, counts.get("1", 0)),
            "n_missing": lab[target].isna().sum(),
            "positive_rate": pd.to_numeric(lab[target], errors="coerce").mean(),
        })
    dist = pd.DataFrame(dist_rows)

    # Label co-occurrence.
    tmp = lab.copy()
    for c in ["label_D", "label_A", "label_S"]:
        tmp[c] = pd.to_numeric(tmp[c], errors="coerce").fillna(-1).astype(int)
    co = (
        tmp.groupby(["label_D", "label_A", "label_S"])
        .size()
        .reset_index(name="n")
        .sort_values("n", ascending=False)
    )

    return dist, co, master2


def summarize_coverage(master: pd.DataFrame, feature_cov: pd.DataFrame, transcript_stats: pd.DataFrame) -> pd.DataFrame:
    rows = []

    def add(metric, value):
        rows.append({"metric": metric, "value": value})

    add("n_participant_session_rows", len(master))
    add("n_unique_participants", master[["school", "class_id", "participant_id"]].drop_duplicates().shape[0])
    add("n_rows_with_feature_session", int(master["has_feature_session"].sum()) if "has_feature_session" in master else 0)
    add("n_rows_with_transcript_session", int(master["has_transcript_session"].sum()) if "has_transcript_session" in master else 0)

    if not feature_cov.empty:
        add("n_feature_coverage_rows", len(feature_cov))
        add("n_sequence_npz_present", int(feature_cov["has_sequence_npz"].sum()))
        add("n_pooled_json_present", int(feature_cov["has_pooled_json"].sum()))
        add("n_pooled_parquet_present", int(feature_cov["has_pooled_parquet"].sum()))

    if not transcript_stats.empty:
        add("n_transcript_rows", len(transcript_stats))
        add("n_clean_transcripts_present", int(transcript_stats["has_clean_transcript"].sum()))
        add("n_nonempty_clean_transcripts", int((~transcript_stats["empty_clean_transcript"]).sum()))

    return pd.DataFrame(rows)


def ssl_model_inventory(feature_cov: pd.DataFrame) -> pd.DataFrame:
    if feature_cov.empty:
        return pd.DataFrame()

    ssl = feature_cov[feature_cov["feature_group"].isin(["ssl_embed", "vision_ssl_embed"])].copy()
    if ssl.empty:
        return pd.DataFrame()

    inv = (
        ssl.groupby(["modality", "feature_group", "model_tag"])
        .agg(
            n_rows=("participant_id", "size"),
            n_sequence=("has_sequence_npz", "sum"),
            n_pooled_json=("has_pooled_json", "sum"),
            n_pooled_parquet=("has_pooled_parquet", "sum"),
            mean_sequence_bytes=("sequence_bytes", "mean"),
        )
        .reset_index()
    )
    inv["sequence_coverage_rate"] = inv["n_sequence"] / inv["n_rows"].clip(lower=1)
    return inv.sort_values(["feature_group", "model_tag"])


def feature_distribution_summary(seq_stats: pd.DataFrame) -> pd.DataFrame:
    if seq_stats.empty:
        return pd.DataFrame()

    group_cols = ["modality", "feature_group", "model_tag", "session"]
    agg = (
        seq_stats.groupby(group_cols, dropna=False)
        .agg(
            n_files=("sequence_path", "size"),
            n_read_ok=("read_ok", "sum"),
            median_n_frames=("n_frames", "median"),
            p10_n_frames=("n_frames", lambda x: np.nanpercentile(x, 10) if len(x.dropna()) else np.nan),
            p90_n_frames=("n_frames", lambda x: np.nanpercentile(x, 90) if len(x.dropna()) else np.nan),
            median_feature_dim=("feature_dim", "median"),
            median_duration_sec=("duration_sec_est", "median"),
            total_nan=("n_nan", "sum"),
            total_inf=("n_inf", "sum"),
            median_zero_ratio=("zero_ratio", "median"),
            median_mean_abs=("mean_abs_value", "median"),
            median_std=("std_value", "median"),
        )
        .reset_index()
    )
    return agg


def save_bar_plot(df: pd.DataFrame, x: str, y: str, title: str, path: Path, rotate: bool = True) -> None:
    if df.empty or x not in df or y not in df:
        return
    plt.figure(figsize=(10, 5))
    plt.bar(df[x].astype(str), df[y])
    plt.title(title)
    plt.xlabel(x)
    plt.ylabel(y)
    if rotate:
        plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()


def make_figures(
    out_dir: Path,
    master: pd.DataFrame,
    feature_cov: pd.DataFrame,
    seq_stats: pd.DataFrame,
    transcript_stats: pd.DataFrame,
    label_dist: pd.DataFrame,
) -> None:
    fig_dir = out_dir / "figures"
    ensure_dir(fig_dir)

    # Session coverage.
    if not master.empty:
        cov = master.groupby("session").agg(
            feature_session_rate=("has_feature_session", "mean"),
            transcript_session_rate=("has_transcript_session", "mean"),
        ).reset_index()
        plt.figure(figsize=(8, 5))
        x = np.arange(len(cov))
        width = 0.35
        plt.bar(x - width/2, cov["feature_session_rate"], width, label="feature")
        plt.bar(x + width/2, cov["transcript_session_rate"], width, label="transcript")
        plt.xticks(x, cov["session"])
        plt.ylim(0, 1.05)
        plt.ylabel("coverage rate")
        plt.title("Session coverage")
        plt.legend()
        plt.tight_layout()
        plt.savefig(fig_dir / "session_coverage.png", dpi=160)
        plt.close()

    # Transcript length by session.
    if not transcript_stats.empty:
        stats = transcript_stats.groupby("session")["clean_char_count"].median().reset_index()
        save_bar_plot(stats, "session", "clean_char_count", "Median clean transcript char count by session", fig_dir / "transcript_length_by_session.png", rotate=False)

    # Sequence length by feature.
    if not seq_stats.empty:
        tmp = seq_stats.copy()
        tmp["feature_label"] = tmp["feature_group"].astype(str) + np.where(tmp["model_tag"].fillna("").astype(str).str.len() > 0, "/" + tmp["model_tag"].astype(str), "")
        stats = tmp.groupby("feature_label")["n_frames"].median().reset_index().sort_values("n_frames", ascending=False)
        save_bar_plot(stats.head(30), "feature_label", "n_frames", "Median n_frames by feature", fig_dir / "sequence_length_by_feature.png", rotate=True)

    # Missing feature heatmap approximation.
    if not feature_cov.empty:
        tmp = feature_cov.copy()
        tmp["feature_label"] = tmp["feature_group"].astype(str) + np.where(tmp["model_tag"].fillna("").astype(str).str.len() > 0, "/" + tmp["model_tag"].astype(str), "")
        piv = tmp.pivot_table(index="feature_label", columns="session", values="has_sequence_npz", aggfunc="mean")
        if not piv.empty:
            plt.figure(figsize=(8, max(5, 0.25 * len(piv))))
            plt.imshow(piv.fillna(0).values, aspect="auto", vmin=0, vmax=1)
            plt.colorbar(label="sequence coverage rate")
            plt.yticks(np.arange(len(piv.index)), piv.index)
            plt.xticks(np.arange(len(piv.columns)), piv.columns)
            plt.title("Sequence coverage heatmap")
            plt.tight_layout()
            plt.savefig(fig_dir / "missing_feature_heatmap.png", dpi=160)
            plt.close()

    # Label distribution.
    if not label_dist.empty:
        plt.figure(figsize=(7, 5))
        x = np.arange(len(label_dist))
        plt.bar(x - 0.2, label_dist["n_0"], width=0.4, label="0")
        plt.bar(x + 0.2, label_dist["n_1"], width=0.4, label="1")
        plt.xticks(x, label_dist["target"])
        plt.ylabel("count")
        plt.title("A1 label distribution")
        plt.legend()
        plt.tight_layout()
        plt.savefig(fig_dir / "label_distribution.png", dpi=160)
        plt.close()


def write_report(
    out_dir: Path,
    split_name: str,
    master: pd.DataFrame,
    coverage_summary: pd.DataFrame,
    feature_cov: pd.DataFrame,
    seq_stats: pd.DataFrame,
    transcript_stats: pd.DataFrame,
    alignment_stats: pd.DataFrame,
    ssl_inv: pd.DataFrame,
    label_dist: pd.DataFrame,
) -> None:
    lines = []
    lines.append(f"# AdoDAS Data Inspection Report: `{split_name}`")
    lines.append("")
    lines.append("## 1. Core summary")
    lines.append("")
    if not coverage_summary.empty:
        lines.append(coverage_summary.to_markdown(index=False))
    lines.append("")

    lines.append("## 2. Session coverage")
    lines.append("")
    if not master.empty:
        sess_cov = master.groupby("session").agg(
            n_rows=("participant_id", "size"),
            feature_session_rate=("has_feature_session", "mean"),
            transcript_session_rate=("has_transcript_session", "mean"),
        ).reset_index()
        lines.append(sess_cov.to_markdown(index=False))
    lines.append("")

    lines.append("## 3. Label distribution")
    lines.append("")
    if label_dist.empty:
        lines.append("No labels CSV was provided or label columns could not be detected.")
    else:
        lines.append(label_dist.to_markdown(index=False))
    lines.append("")

    lines.append("## 4. Feature sequence coverage")
    lines.append("")
    if not feature_cov.empty:
        tmp = feature_cov.copy()
        tmp["feature_label"] = tmp["feature_group"].astype(str) + np.where(tmp["model_tag"].fillna("").astype(str).str.len() > 0, "/" + tmp["model_tag"].astype(str), "")
        cov = tmp.groupby(["modality", "feature_label", "session"]).agg(
            n_rows=("participant_id", "size"),
            sequence_rate=("has_sequence_npz", "mean"),
            pooled_json_rate=("has_pooled_json", "mean"),
            pooled_parquet_rate=("has_pooled_parquet", "mean"),
        ).reset_index()
        lines.append(cov.head(80).to_markdown(index=False))
        if len(cov) > 80:
            lines.append("")
            lines.append(f"Only first 80 rows shown. Full table: `02_feature_file_coverage.csv`.")
    lines.append("")

    lines.append("## 5. Sequence shape warnings")
    lines.append("")
    if seq_stats.empty:
        lines.append("No sequence stats available.")
    else:
        bad = seq_stats[(seq_stats["read_ok"] != True) | (seq_stats["n_nan"].fillna(0) > 0) | (seq_stats["n_inf"].fillna(0) > 0)]
        lines.append(f"Total sequence files inspected: {len(seq_stats)}")
        lines.append("")
        lines.append(f"Files with read/NaN/Inf issues: {len(bad)}")
        if len(bad) > 0:
            lines.append("")
            cols = ["participant_id", "session", "feature_group", "model_tag", "read_ok", "n_nan", "n_inf", "error"]
            lines.append(bad[cols].head(30).to_markdown(index=False))
    lines.append("")

    lines.append("## 6. Transcript summary")
    lines.append("")
    if transcript_stats.empty:
        lines.append("No transcript stats available.")
    else:
        tr = transcript_stats.groupby("session").agg(
            n_rows=("participant_id", "size"),
            transcript_session_rate=("has_transcript_session", "mean"),
            clean_present_rate=("has_clean_transcript", "mean"),
            nonempty_clean_rate=("empty_clean_transcript", lambda x: 1 - float(np.mean(x))),
            median_clean_chars=("clean_char_count", "median"),
            median_clean_tokens=("clean_token_count", "median"),
            median_segments_csv=("segment_count_csv", "median"),
        ).reset_index()
        lines.append(tr.to_markdown(index=False))
    lines.append("")

    lines.append("## 7. VAD-transcript alignment")
    lines.append("")
    if alignment_stats.empty:
        lines.append("No alignment stats available.")
    else:
        al = alignment_stats.groupby("session").agg(
            n_rows=("participant_id", "size"),
            median_audio_vad_sec=("audio_vad_speech_sec", "median"),
            median_transcript_sec=("transcript_segment_sec", "median"),
            median_abs_diff_sec=("duration_diff_sec", lambda x: float(np.nanmedian(np.abs(x)))),
            median_diff_ratio=("duration_diff_ratio", "median"),
        ).reset_index()
        lines.append(al.to_markdown(index=False))
    lines.append("")

    lines.append("## 8. SSL model inventory")
    lines.append("")
    if ssl_inv.empty:
        lines.append("No SSL model inventory available.")
    else:
        lines.append(ssl_inv.to_markdown(index=False))
    lines.append("")

    lines.append("## 9. Initial model-enhancement reading")
    lines.append("")
    lines.append("- If transcripts have high coverage and non-trivial length, add a session-level text branch.")
    lines.append("- If B01/B02/B03 have very different coverage or text length, replace mean session aggregation with attention.")
    lines.append("- If QC/VAD vary heavily, add quality-aware modality gating.")
    lines.append("- If `body_pose` and `global_motion` have high coverage and clean shapes, run ablations to add them.")
    lines.append("- If another SSL model has better coverage or cleaner shape stats, compare it against the current baseline SSL tags.")
    lines.append("")

    (out_dir / "report.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect AdoDAS feature/transcript data.")
    parser.add_argument("--features-root", type=Path, required=True, help="Root above SCH_*/CLS_*/P* feature folders.")
    parser.add_argument("--transcript-root", type=Path, default=None, help="Root above SCH_*/CLS_*/P* transcript folders.")
    parser.add_argument("--labels-csv", type=Path, default=None, help="Optional A1 labels CSV.")
    parser.add_argument("--split-name", type=str, default="train", help="Split name, e.g. train or val.")
    parser.add_argument("--out-dir", type=Path, required=True, help="Output directory.")
    parser.add_argument("--max-participants", type=int, default=None, help="Optional debug sampling limit.")
    args = parser.parse_args()

    ensure_dir(args.out_dir)
    ensure_dir(args.out_dir / "figures")

    print(f"[INFO] features_root:   {args.features_root}")
    print(f"[INFO] transcript_root: {args.transcript_root}")
    print(f"[INFO] labels_csv:      {args.labels_csv}")
    print(f"[INFO] split_name:      {args.split_name}")
    print(f"[INFO] out_dir:         {args.out_dir}")

    participants = make_participant_paths(
        features_root=args.features_root,
        transcript_root=args.transcript_root,
        max_participants=args.max_participants,
    )
    print(f"[INFO] participants found: {len(participants)}")

    master = inspect_master_index(participants)
    label_dist, label_co, master = inspect_labels(args.labels_csv, master, args.out_dir)
    master.to_csv(args.out_dir / "00_master_index.csv", index=False)

    if not label_dist.empty:
        label_dist.to_csv(args.out_dir / "01_label_distribution.csv", index=False)
    if not label_co.empty:
        label_co.to_csv(args.out_dir / "01_label_cooccurrence.csv", index=False)

    feature_cov = inspect_feature_coverage(participants)
    feature_cov.to_csv(args.out_dir / "02_feature_file_coverage.csv", index=False)

    seq_stats = inspect_sequence_stats(feature_cov)
    seq_stats.to_csv(args.out_dir / "03_sequence_shape_stats.csv", index=False)

    pooled_stats = inspect_pooled_stats(feature_cov)
    pooled_stats.to_csv(args.out_dir / "04_pooled_file_stats.csv", index=False)

    transcript_stats = inspect_transcripts(participants)
    transcript_stats.to_csv(args.out_dir / "05_transcript_stats.csv", index=False)

    alignment_stats = inspect_vad_transcript_alignment(participants)
    alignment_stats.to_csv(args.out_dir / "06_vad_transcript_alignment_stats.csv", index=False)

    dist_stats = feature_distribution_summary(seq_stats)
    dist_stats.to_csv(args.out_dir / "07_feature_distribution_stats.csv", index=False)

    ssl_inv = ssl_model_inventory(feature_cov)
    ssl_inv.to_csv(args.out_dir / "08_ssl_model_inventory.csv", index=False)

    coverage_summary = summarize_coverage(master, feature_cov, transcript_stats)
    coverage_summary.to_csv(args.out_dir / "00_coverage_summary.csv", index=False)

    make_figures(
        out_dir=args.out_dir,
        master=master,
        feature_cov=feature_cov,
        seq_stats=seq_stats,
        transcript_stats=transcript_stats,
        label_dist=label_dist,
    )

    write_report(
        out_dir=args.out_dir,
        split_name=args.split_name,
        master=master,
        coverage_summary=coverage_summary,
        feature_cov=feature_cov,
        seq_stats=seq_stats,
        transcript_stats=transcript_stats,
        alignment_stats=alignment_stats,
        ssl_inv=ssl_inv,
        label_dist=label_dist,
    )

    print("[INFO] Done.")
    print(f"[INFO] Main report: {args.out_dir / 'report.md'}")


if __name__ == "__main__":
    main()
