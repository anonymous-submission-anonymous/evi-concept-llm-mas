# Raw Concept Extraction with Qwen3.5-9B + vLLM

This project extracts post-local raw concepts from:

```bash
/mnt/disk1/wbjtu/tzbjtu/somental/data/anonymizing_sentiment_cleaned.csv
```

using local model:

```bash
/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B
```

It filters out posts with fewer than 10 words and posts containing no alphanumeric characters, splits the remaining data into 4 shards, runs one shard per L20 GPU, removes concepts containing forbidden label terms, and merges all shard outputs.

## Run

```bash
conda activate concepts
cd raw_concept_extraction_qwen35_9b
bash scripts/00_prepare.sh
bash scripts/01_run_4gpu.sh
bash scripts/02_merge.sh
```

## Outputs

```bash
outputs/prepared/filtered.csv
outputs/prepared/shards/shard_00.csv
outputs/prepared/shards/shard_01.csv
outputs/prepared/shards/shard_02.csv
outputs/prepared/shards/shard_03.csv
outputs/shards/shard_00_concepts.jsonl
outputs/shards/shard_01_concepts.jsonl
outputs/shards/shard_02_concepts.jsonl
outputs/shards/shard_03_concepts.jsonl
outputs/merged/raw_concepts_merged.jsonl
outputs/merged/raw_concepts_merged.csv
```
