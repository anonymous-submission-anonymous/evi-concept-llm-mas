#!/usr/bin/env bash
set -euo pipefail
python src/merge_outputs.py --config configs/config.yaml
