#!/usr/bin/env bash
set -euo pipefail
python src/prepare_data.py --config configs/config.yaml
