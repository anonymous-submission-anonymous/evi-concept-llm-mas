#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs outputs/shards

for SHARD in 0 1 2 3; do
  CUDA_VISIBLE_DEVICES=${SHARD} nohup python src/extract_concepts.py \
    --config configs/config.yaml \
    --shard-id ${SHARD} \
    > logs/shard_${SHARD}.log 2>&1 &
  echo "Started shard ${SHARD} on GPU ${SHARD}. Log: logs/shard_${SHARD}.log"
done

wait
echo "All shards finished."
