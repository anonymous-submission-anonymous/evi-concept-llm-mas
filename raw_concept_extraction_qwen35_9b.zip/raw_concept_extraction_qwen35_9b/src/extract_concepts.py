import argparse
import json
from pathlib import Path

import pandas as pd
from tqdm import tqdm
from transformers import AutoTokenizer
from vllm import LLM, SamplingParams

from common import build_prompt, clean_concepts, concept_budget, ensure_dir, load_config


def apply_chat_template(tokenizer, prompt: str) -> str:
    messages = [{"role": "user", "content": prompt}]
    try:
        return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    except Exception:
        return prompt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--shard-id", type=int, required=True)
    ap.add_argument("--batch-size", type=int, default=64)
    args = ap.parse_args()
    cfg = load_config(args.config)

    shard_path = Path(cfg["output_root"]) / "prepared" / "shards" / f"shard_{args.shard_id:02d}.csv"
    out_dir = ensure_dir(Path(cfg["output_root"]) / "shards")
    out_path = out_dir / f"shard_{args.shard_id:02d}_concepts.jsonl"

    df = pd.read_csv(shard_path)
    text_col = cfg["text_col"]
    id_col = cfg.get("id_col", "post_id")
    forbidden = cfg.get("forbidden_concept_substrings", [])

    gen_cfg = cfg["generation"]
    tokenizer = AutoTokenizer.from_pretrained(cfg["model_path"], trust_remote_code=bool(gen_cfg.get("trust_remote_code", True)))
    llm = LLM(
        model=cfg["model_path"],
        tensor_parallel_size=int(gen_cfg.get("tensor_parallel_size", 1)),
        gpu_memory_utilization=float(gen_cfg.get("gpu_memory_utilization", 0.90)),
        trust_remote_code=bool(gen_cfg.get("trust_remote_code", True)),
    )

    rows = []
    for idx, row in df.iterrows():
        n_words = int(row["word_count"])
        max_concepts, max_tokens = concept_budget(n_words)
        prompt = build_prompt(str(row[text_col]), max_concepts)
        rows.append((idx, row, apply_chat_template(tokenizer, prompt), max_concepts, max_tokens))

    with open(out_path, "w", encoding="utf-8") as f:
        for max_tokens in sorted(set(r[4] for r in rows)):
            bucket = [r for r in rows if r[4] == max_tokens]
            sp = SamplingParams(
                temperature=float(gen_cfg.get("temperature", 0.0)),
                top_p=float(gen_cfg.get("top_p", 1.0)),
                max_tokens=int(max_tokens),
            )
            for start in tqdm(range(0, len(bucket), args.batch_size), desc=f"shard {args.shard_id} max_tokens {max_tokens}"):
                batch = bucket[start:start + args.batch_size]
                outputs = llm.generate([x[2] for x in batch], sp)
                for item, out in zip(batch, outputs):
                    _, row, _, max_concepts, max_tok = item
                    raw = out.outputs[0].text if out.outputs else ""
                    concepts, status = clean_concepts(raw, forbidden)
                    rec = {
                        id_col: row[id_col],
                        "users": row.get("users", None),
                        "sentiment": row.get("sentiment", None),
                        "time": row.get("time", None),
                        "word_count": int(row["word_count"]),
                        "max_concepts": int(max_concepts),
                        "max_tokens": int(max_tok),
                        "concepts": concepts,
                        "status": status,
                        "raw_generation": raw,
                    }
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    f.flush()

    print(f"Saved: {out_path}")


if __name__ == "__main__":
    main()
