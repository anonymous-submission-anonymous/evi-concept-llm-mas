import argparse
import json
from pathlib import Path

import pandas as pd

from common import ensure_dir, load_config


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)

    out_root = Path(cfg["output_root"])
    shard_dir = out_root / "shards"
    merge_dir = ensure_dir(out_root / "merged")
    jsonl_path = merge_dir / "raw_concepts_merged.jsonl"
    csv_path = merge_dir / "raw_concepts_merged.csv"

    records = []
    shard_files = sorted(shard_dir.glob("shard_*_concepts.jsonl"))
    if not shard_files:
        raise FileNotFoundError(f"No shard outputs found in {shard_dir}")

    with open(jsonl_path, "w", encoding="utf-8") as fout:
        for path in shard_files:
            with open(path, "r", encoding="utf-8") as fin:
                for line in fin:
                    if not line.strip():
                        continue
                    rec = json.loads(line)
                    fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    records.append(rec)

    df = pd.DataFrame(records)
    df["concepts_json"] = df["concepts"].map(lambda x: json.dumps(x, ensure_ascii=False))
    df.drop(columns=["concepts"], errors="ignore").to_csv(csv_path, index=False)

    print(f"Merged records: {len(records)}")
    print(f"Status counts:\n{df['status'].value_counts(dropna=False)}")
    print(f"Saved: {jsonl_path}")
    print(f"Saved: {csv_path}")


if __name__ == "__main__":
    main()
