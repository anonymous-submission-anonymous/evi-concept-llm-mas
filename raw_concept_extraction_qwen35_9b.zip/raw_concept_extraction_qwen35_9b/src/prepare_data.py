import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from common import ensure_dir, has_alnum, load_config, word_count


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)

    out_root = Path(cfg["output_root"])
    prep_dir = ensure_dir(out_root / "prepared")
    shard_dir = ensure_dir(prep_dir / "shards")

    df = pd.read_csv(cfg["data_path"])
    text_col = cfg["text_col"]
    if text_col not in df.columns:
        raise ValueError(f"Missing text column: {text_col}")

    if cfg.get("id_col", "post_id") not in df.columns:
        df.insert(0, cfg.get("id_col", "post_id"), [f"post_{i:06d}" for i in range(len(df))])

    df[text_col] = df[text_col].fillna("").astype(str)
    df["word_count"] = df[text_col].map(word_count)
    df = df[(df["word_count"] >= int(cfg["min_words"])) & (df[text_col].map(has_alnum))].copy()
    df = df.reset_index(drop=True)

    filtered_path = prep_dir / "filtered.csv"
    df.to_csv(filtered_path, index=False)

    shards = np.array_split(df, int(cfg["num_shards"]))
    for i, shard in enumerate(shards):
        shard.to_csv(shard_dir / f"shard_{i:02d}.csv", index=False)

    print(f"Input rows after filtering: {len(df)}")
    print(f"Saved: {filtered_path}")
    print(f"Saved {len(shards)} shards to: {shard_dir}")


if __name__ == "__main__":
    main()
