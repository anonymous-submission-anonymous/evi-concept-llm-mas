import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

import yaml


def load_config(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def word_count(text: str) -> int:
    return len(re.findall(r"\b\w+\b", str(text)))


def has_alnum(text: str) -> bool:
    return bool(re.search(r"[A-Za-z0-9]", str(text)))


def concept_budget(n_words: int) -> Tuple[int, int]:
    if n_words <= 20:
        return 1, 48
    if n_words <= 60:
        return 2, 64
    if n_words <= 150:
        return 4, 96
    if n_words <= 350:
        return 6, 128
    if n_words <= 800:
        return 8, 192
    return 10, 256


def build_prompt(text: str, max_concepts: int) -> str:
    return f'''Extract raw concepts from the post.

A raw concept is a short human-readable phrase that directly summarizes one concrete thought, feeling, event, behavior, method, situation, relationship, risk factor, or protective factor explicitly expressed in the post.

Rules:
1. Extract only concepts directly supported by the post.
2. Do not use any predefined concept list.
3. Do not normalize concepts into a taxonomy.
4. Do not map concepts to clinical categories.
5. Do not infer hidden diagnosis, intent, or emotion unless the post clearly states it.
6. Do not output final labels: Indicator, Ideation, Behavior, Attempt.
7. Do not output explanations.
8. Do not output duplicate concepts.
9. If the post has no meaningful concept, return an empty list.
10. Output valid JSON only.

Maximum number of concepts: {max_concepts}

Post:
{text}

Return exactly this JSON format:
{{
  "concepts": ["concept 1", "concept 2"]
}}'''


def extract_json_object(raw: str) -> Dict[str, Any]:
    raw = raw.strip()
    try:
        return json.loads(raw)
    except Exception:
        pass
    m = re.search(r"\{.*\}", raw, flags=re.S)
    if not m:
        raise ValueError("no JSON object found")
    return json.loads(m.group(0))


def clean_concepts(raw: str, forbidden: List[str]) -> Tuple[List[str], str]:
    try:
        obj = extract_json_object(raw)
        concepts = obj.get("concepts", [])
        if not isinstance(concepts, list):
            return [], "concepts_not_list"
    except Exception as e:
        return [], f"parse_error: {repr(e)}"

    cleaned, seen = [], set()
    forbidden_l = [x.lower() for x in forbidden]
    for c in concepts:
        if not isinstance(c, str):
            continue
        c = re.sub(r"\s+", " ", c.strip().strip('"').strip("'"))
        if not c:
            continue
        if len(c) > 120:
            continue
        c_l = c.lower()
        if any(term in c_l for term in forbidden_l):
            continue
        if c_l not in seen:
            cleaned.append(c)
            seen.add(c_l)
    return cleaned, "ok"
